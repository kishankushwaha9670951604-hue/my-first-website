(() => {
"use strict";
const CATS = ["Shirt", "Pant", "T-shirt", "Lower", "Extra"];
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const rs = (n) => "₹" + Number(n || 0).toLocaleString("en-IN");
const S = { token: localStorage.getItem("kf_token") || "", me: null, settings: {}, products: [], bookings: [], payments: [], customers: [], inventory: [], accounts: [], users: 0, loaded: false };
const SIZES = ["S", "M", "L", "XL", "XXL"], COLOURS = ["Black", "White", "Blue", "Navy", "Grey", "Beige", "Olive", "Red", "Green", "Maroon"];
const ST_LBL = { pending: "⏳ Pending", confirmed: "✅ Confirmed", picked_up: "🛍️ Picked up", cancelled: "✕ Cancelled", no_show: "🚫 No-show" };
const PM_LBL = { cash: "Cash", upi: "UPI", card: "Card" };
const vidOf = (size, colour) => { const sl = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9\u0900-\u097f]+/g, "-").replace(/^-|-$/g, "") || "x"; return !size && !colour ? "std" : sl(size || "any") + "__" + sl(colour || "any"); };
const WL = { get: () => { try { return JSON.parse(localStorage.getItem("kf_wish") || "[]"); } catch { return []; } }, set: (a) => localStorage.setItem("kf_wish", JSON.stringify(a)) };
const LOW = 3;
const F = { cat: "All", q: "" };
const TAGS = { new: "✨ New", best: "🔥 Bestseller" };
const isOwner = () => S.me && S.me.role === "owner";
let ADMIN_PAGE = /^\/admin\/?$/.test(location.pathname);

async function api(path, opts = {}) {
  const o = { method: opts.method || "GET", headers: { "content-type": "application/json" } };
  if (S.token) o.headers.authorization = "Bearer " + S.token;
  if (opts.body) o.body = JSON.stringify(opts.body);
  let r, d;
  try { r = await fetch("/api" + path, o); d = await r.json(); } catch { throw new Error("Please check your internet and try again"); }
  if (!d.ok) { if (r.status === 403 && isOwner()) { setSession("", null); } throw new Error(d.error || "Something went wrong"); }
  return d;
}
function toast(t) { const e = $("#toast"); e.textContent = t; e.classList.add("show"); clearTimeout(e._t); e._t = setTimeout(() => e.classList.remove("show"), 2600); }
function msg(el, t, ok) { el.textContent = t || ""; el.className = "formmsg " + (t ? (ok ? "ok" : "bad") : ""); }
function setSession(token, me) { S.token = token || ""; S.me = me; token ? localStorage.setItem("kf_token", token) : localStorage.removeItem("kf_token"); renderAll(); }

const offPct = (p) => (p.mrp && p.mrp > p.price ? Math.round((1 - p.price / p.mrp) * 100) : 0);
const priceHTML = (p, big) => `<div class="price${big ? " big" : ""}">${rs(p.price)}${offPct(p) ? ` <s>${rs(p.mrp)}</s> <span class="off">${offPct(p)}% off</span>` : ""}</div>`;
const isOOS = (p) => p.status === "out_of_stock" || p.stock <= 0;
function stockTxt(n) { return n <= 0 ? '<span class="stock out">Out of stock</span>' : n <= 5 ? `<span class="stock low">Only ${n} left</span>` : `<span class="stock">Stock: ${n}</span>`; }
function card(p, i = 0) {
  return `<button type="button" class="pcard" data-pid="${esc(p.id)}" style="--d:${Math.min(i, 12) * 40}ms"><div class="ph">${p.img ? `<img src="${esc(p.img)}" alt="${esc(p.name)}" loading="lazy" decoding="async">` : ""}${p.tag && TAGS[p.tag] ? `<span class="tag t-${p.tag}">${TAGS[p.tag]}</span>` : ""}<span class="wl${WL.get().includes(p.id) ? " on" : ""}" data-wl="${esc(p.id)}" role="button" aria-label="Wishlist">${WL.get().includes(p.id) ? "❤️" : "🤍"}</span>${(p.images || []).length > 1 ? `<span class="nimg">📷 ${p.images.length}</span>` : ""}</div>
  <div class="bd"><small class="cat">${esc(p.cat)}</small><h3>${esc(p.name)}</h3>${priceHTML(p)}${p.status === "out_of_stock" ? stockTxt(0) : stockTxt(p.stock)}${(p.colours || []).length ? `<small class="cols">${p.colours.length} colour · ${(p.sizes || []).join(" ") }</small>` : (p.sizes || []).length ? `<small class="cols">${p.sizes.join(" ")}</small>` : ""}</div></button>`;
}
const skel = (n) => Array.from({ length: n }, () => '<div class="pcard sk"><div class="ph"></div><div class="bd"><i></i><i></i><i class="s"></i></div></div>').join("");
const telNum = () => { const s = S.settings, n = String(s.phone || s.whatsapp || "").replace(/[^\d+]/g, ""); if (!n) return ""; const d = n.replace(/\D/g, ""); return n.startsWith("+") ? n : d.length === 10 ? "+91" + d : d.length === 12 && d.startsWith("91") ? "+" + d : n; };
function mapsUrl() { const s = S.settings; if (s.mapsUrl) return s.mapsUrl; if (s.address) return "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent((s.brand || "") + " " + s.address); return ""; }
const DAYN = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], DAYS3 = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const t12 = (t) => { const [H, M] = String(t || "").split(":").map(Number); if (isNaN(H)) return t || ""; return `${H % 12 || 12}${M ? ":" + String(M).padStart(2, "0") : ""} ${H < 12 ? "AM" : "PM"}`; };
const hoursArr = () => (Array.isArray(S.settings.hours) && S.settings.hours.length === 7 ? S.settings.hours : null);
function hoursGroups() { const h = hoursArr(); if (!h) return []; const order = [1, 2, 3, 4, 5, 6, 0], g = [];
  for (const d of order) { const v = h[d], lbl = v.x ? "Closed" : t12(v.o) + " – " + t12(v.c), last = g[g.length - 1]; if (last && last.lbl === lbl) last.to = d; else g.push({ from: d, to: d, lbl }); }
  return g.map((x) => ({ days: x.from === x.to ? DAYS3[x.from] : DAYS3[x.from] + "–" + DAYS3[x.to], lbl: x.lbl })); }
function timingText() { const g = hoursGroups(); if (!g.length) return S.settings.timing || "10:00 AM – 9:00 PM"; return g.length === 1 ? "Daily " + g[0].lbl : g.map((x) => x.days + ": " + x.lbl).join(", "); }
function todayLine() { const h = hoursArr(); if (!h) return ""; const v = h[new Date().getDay()]; return v.x ? "Closed today" : "Today: " + t12(v.o) + " – " + t12(v.c); }
const ICO = { ig: '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm0 8.2a3.2 3.2 0 1 1 0-6.4 3.2 3.2 0 0 1 0 6.4ZM17.3 5.5a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4ZM12 2c-2.7 0-3.1 0-4.1.1C4.6 2.2 2.2 4.6 2.1 7.9 2 8.9 2 9.3 2 12s0 3.1.1 4.1c.1 3.3 2.5 5.7 5.8 5.8 1 .1 1.4.1 4.1.1s3.1 0 4.1-.1c3.3-.1 5.7-2.5 5.8-5.8.1-1 .1-1.4.1-4.1s0-3.1-.1-4.1c-.1-3.3-2.5-5.7-5.8-5.8C15.1 2 14.7 2 12 2Zm0 1.8c2.7 0 3 0 4 .1 2.3.1 3.9 1.7 4 4 .1 1 .1 1.3.1 4.1s0 3-.1 4c-.1 2.3-1.7 3.9-4 4-1 .1-1.3.1-4 .1s-3 0-4-.1c-2.3-.1-3.9-1.7-4-4-.1-1-.1-1.3-.1-4s0-3 .1-4c.1-2.3 1.7-3.9 4-4 1-.1 1.3-.1 4-.1Z"/></svg>',
  fb: '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M13.5 22v-8h2.7l.4-3.2h-3.1V8.8c0-.9.3-1.5 1.6-1.5h1.7V4.4c-.3 0-1.3-.1-2.5-.1-2.4 0-4.1 1.5-4.1 4.2v2.3H7.5V14h2.7v8h3.3Z"/></svg>' };
function socialHTML() { const s = S.settings; return (s.instagram ? `<a class="soc ig" href="${esc(s.instagram)}" target="_blank" rel="noopener" aria-label="Instagram">${ICO.ig}<span>Instagram</span></a>` : "") + (s.facebook ? `<a class="soc fb" href="${esc(s.facebook)}" target="_blank" rel="noopener" aria-label="Facebook">${ICO.fb}<span>Facebook</span></a>` : ""); }
function infoHTML() {
  const s = S.settings, tel = telNum(), mu = mapsUrl(), wa = s.whatsapp ? String(s.whatsapp).replace(/\D/g, "") : "";
  return `<div class="info card"><h3>${esc(s.brand || "Raj Men's Wear")}</h3>
  <div class="irow"><span>📍</span><div><b>Address</b><p>${s.address ? esc(s.address) : "Call us for the address"}</p></div></div>
  <div class="irow"><span>🕘</span><div><b>Opening hours</b>${hoursArr() ? `<p class="today">${esc(todayLine())}</p><ul class="hlist">${hoursGroups().map((g) => `<li><span>${esc(g.days)}</span><span>${esc(g.lbl)}</span></li>`).join("")}</ul>` : `<p>${esc(s.timing || "10:00 AM – 9:00 PM")}</p>`}</div></div>
  ${tel ? `<div class="irow"><span>📞</span><div><b>Phone</b><p>${esc(tel)}</p></div></div>` : ""}
  ${s.email ? `<div class="irow"><span>✉️</span><div><b>Email</b><p><a href="mailto:${esc(s.email)}">${esc(s.email)}</a></p></div></div>` : ""}
  ${(() => { const pm = s.payModes || {}, modes = [pm.cash && "Cash", pm.upi && "UPI", pm.card && "Card"].filter(Boolean); return (modes.length || s.upi) ? `<div class="irow"><span>💳</span><div><b>Payment</b>${modes.length ? `<p>${modes.map((x) => `<span class="pill">${x}</span>`).join(" ")}</p>` : ""}${s.upi ? `<p class="upi">UPI: <span class="upiv">${esc(s.upi)}</span> <button type="button" class="link" data-copy="${esc(s.upi)}">Copy</button></p>` : ""}</div></div>` : ""; })()}
  ${s.delivery || s.alteration ? `<div class="irow"><span>🚚</span><div><b>Services</b>${s.delivery ? `<p>✓ Home delivery${s.deliveryAreas ? " · " + esc(s.deliveryAreas) : ""}${s.deliveryCharge ? " · " + esc(s.deliveryCharge) : ""}</p>` : ""}${s.alteration ? "<p>✓ Alterations / tailoring available</p>" : ""}</div></div>` : ""}
  ${s.returnPolicy ? `<div class="irow"><span>🔁</span><div><b>Return / Exchange</b><p>${esc(s.returnPolicy)}</p></div></div>` : ""}
  ${s.gst ? `<div class="irow"><span>🧾</span><div><b>GST</b><p>${esc(s.gst)}</p></div></div>` : ""}
  ${socialHTML() ? `<div class="social">${socialHTML()}</div>` : ""}
  <div class="ibtns">${tel ? `<a class="btn gold" href="tel:${esc(tel)}">📞 Call now</a>` : ""}${mu ? `<a class="btn ghost" href="${esc(mu)}" target="_blank" rel="noopener">🗺️ Google Maps</a>` : ""}${wa ? `<a class="btn ghost" href="https://wa.me/${esc(wa)}" target="_blank" rel="noopener">💬 WhatsApp</a>` : ""}<a class="btn ghost" href="#booking">📅 Book a visit</a></div></div>`;
}
function parseReviews() { return String(S.settings.reviews || "").split("\n").map((l) => l.trim()).filter(Boolean).map((l) => { const i = l.indexOf("|"); return i > 0 ? { n: l.slice(0, i).trim(), t: l.slice(i + 1).trim() } : { n: "Customer", t: l }; }).filter((r) => r.t).slice(0, 8); }
function renderBrand() {
  const s = S.settings, b = s.brand || "Raj Men's Wear";
  document.title = b + " – Shirts, Pants, T-shirts & more";
  for (const id of ["brandName", "heroBrand", "footBrand"]) $("#" + id).textContent = b;
  const markH = s.logo ? `<img src="${esc(s.logo)}" alt="">` : esc(b.trim().charAt(0).toUpperCase() || "K");
  $$(".mark").forEach((m) => { m.innerHTML = markH; m.classList.toggle("haslogo", !!s.logo); });
  $("#footSocial").innerHTML = socialHTML(); $("#footTag").textContent = s.tagline || b; $("#dashBrand").textContent = b;
  $("#tagline").textContent = s.tagline || "";
  const meta = [s.address && "📍 " + s.address, "🕘 " + timingText()].filter(Boolean).join("  ·  ");
  $("#footMeta").textContent = meta;
  const ob = $("#offerBar"), on = s.offerOn !== false && !!s.offerText; ob.hidden = !on; document.body.classList.toggle("has-offer", on);
  if (on) { $("#offerText").textContent = s.offerText; $("#offerSub").textContent = s.offerSub ? s.offerSub + " →" : ""; $("#offerSub").hidden = !s.offerSub; }
  $("#infoHome").innerHTML = S.loaded ? infoHTML() : ""; $("#infoContact").innerHTML = infoHTML();
  const rv = parseReviews(); $("#reviewsWrap").hidden = !rv.length;
  $("#reviews").innerHTML = rv.map((r) => `<figure class="rv"><div class="stars">★★★★★</div><blockquote>${esc(r.t)}</blockquote><figcaption>— ${esc(r.n)}</figcaption></figure>`).join("");
}
function renderHome() {
  const pics = [...new Set(S.products.filter((p) => p.status !== "hidden").flatMap((p) => p.images && p.images.length ? p.images : p.img ? [p.img] : []))].slice(0, 3);
  const hb = $("#heroBg"), hk = pics.join("|"); if (hb.dataset.k !== hk) { hb.dataset.k = hk; hb.innerHTML = pics.map((u) => `<img src="${esc(u)}" alt="" onerror="this.remove()">`).join(""); hb.className = "hero-bg n" + pics.length; }
  $("#hero").classList.toggle("hero-empty", !pics.length);
  const nw = S.products.filter((p) => p.tag === "new"), bs = S.products.filter((p) => p.tag === "best");
  $("#hlNew").hidden = !nw.length; $("#rowNew").innerHTML = nw.slice(0, 10).map(card).join("");
  $("#hlBest").hidden = !bs.length; $("#rowBest").innerHTML = bs.slice(0, 10).map(card).join("");
  renderShop();
}
function renderShop() {
  const cats = CATS.concat([...new Set(S.products.map((p) => p.cat))].filter((c) => !CATS.includes(c)));
  $("#chips").innerHTML = ["All", ...cats].map((c) => { const n = c === "All" ? S.products.length : S.products.filter((p) => p.cat === c).length;
    return `<button type="button" role="tab" class="chip${F.cat === c ? " on" : ""}" data-cat="${esc(c)}" aria-selected="${F.cat === c}">${c === "All" ? "All" : esc(c)}${S.loaded ? ` <small>${n}</small>` : ""}</button>`; }).join("");
  if (!S.loaded) { $("#catGrid").innerHTML = skel(6); $("#catCount").textContent = ""; return; }
  const none = !S.products.length; $("#shopFilters").hidden = none;
  if (none) { $("#catCount").textContent = ""; $("#catGrid").innerHTML = `<div class="soon" style="grid-column:1/-1"><span class="soon-ic" aria-hidden="true">✨</span><h3>New collection coming soon</h3><p>We're adding fresh styles to the store. Visit us or book a shop visit to see what's new.</p><a class="btn gold" href="#booking">📅 Book a shop visit</a></div>`; $("#qx").hidden = true; return; }
  const q = F.q.trim().toLowerCase(), words = q.split(/\s+/).filter(Boolean);
  const ps = S.products.filter((p) => (F.cat === "All" || p.cat === F.cat) && words.every((w) => (p.name + " " + p.cat + " " + (p.desc || "") + " " + (p.sizes || []).join(" ") + " " + (p.colours || []).join(" ") + " " + (p.tag === "new" ? "new arrivals" : p.tag === "best" ? "bestseller best" : "")).toLowerCase().includes(w)));
  $("#catCount").textContent = ps.length + " items";
  $("#catGrid").innerHTML = ps.map(card).join("") || `<div class="empty" style="grid-column:1/-1">😕 No results for "${esc(F.q || F.cat)}".<br><button type="button" class="link" id="clrF">View all products</button></div>`;
  $("#qx").hidden = !F.q;
}
function scrollShop() { const el = $("#shop"); if (el) setTimeout(() => window.scrollTo({ top: el.getBoundingClientRect().top + scrollY - ($(".top").offsetHeight || 0) - 6, behavior: "smooth" }), 30); }
$("#chips").addEventListener("click", (e) => { const b = e.target.closest("[data-cat]"); if (!b) return; F.cat = b.dataset.cat; renderShop(); b.scrollIntoView && $("#chips .on")?.scrollIntoView({ inline: "center", block: "nearest" }); });
$("#q").addEventListener("input", (e) => { F.q = e.target.value; renderShop(); });
$("#q").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); e.target.blur(); scrollShop(); } });
$("#qx").onclick = () => { F.q = ""; $("#q").value = ""; renderShop(); $("#q").focus(); };
document.addEventListener("click", (e) => { if (e.target.id === "clrF") { F.q = ""; F.cat = "All"; $("#q").value = ""; renderShop(); } });
$("#heroShop").addEventListener("click", (e) => { e.preventDefault(); if ((location.hash || "#home") !== "#home") location.hash = "home"; scrollShop(); });
function renderAccount() {
  $("#accountBtn").textContent = S.me ? (isOwner() ? "📊 Dashboard" : "Hi, " + S.me.name.split(" ")[0]) : "Login / Sign up";
  $("#ownerTab").hidden = !isOwner();
  $("#bookLoginNote").hidden = !!S.me;
  const f = $("#bookForm"); if (S.me && !isOwner() && !f.name.value) f.name.value = S.me.name;
}
function renderPrices() {
  const own = isOwner();
  $("#priceNote").textContent = own ? "Change prices and save" : "Prices for all items (view only)";
  $("#priceSaveBar").hidden = !own;
  if (own) {
    const units = S.products.reduce((a, p) => a + p.stock, 0), val = S.products.reduce((a, p) => a + p.stock * p.price, 0);
    $("#priceSummary").innerHTML = `<div class="stats"><div class="stat"><b>${S.products.length}</b><small>Products</small></div><div class="stat"><b>${units}</b><small>Total stock</small></div><div class="stat"><b>${rs(val)}</b><small>Stock value</small></div></div>`;
  } else $("#priceSummary").innerHTML = "";
  $("#priceList").innerHTML = CATS.map((c) => {
    const ps = S.products.filter((p) => p.cat === c); if (!ps.length) return "";
    const lo = Math.min(...ps.map((p) => p.price)), hi = Math.max(...ps.map((p) => p.price));
    return `<div class="pgroup"><h3>${c} <span class="muted">${lo === hi ? rs(lo) : rs(lo) + " – " + rs(hi)}</span></h3>${ps.map((p) => `<div class="prow"><img src="${esc(p.img)}" alt="" loading="lazy"><div class="n">${esc(p.name)}<small>Stock: ${p.stock}</small></div>${own ? `<label>₹ <input type="number" min="0" inputmode="numeric" name="${esc(p.id)}" value="${p.price}" aria-label="Price ${esc(p.name)}"></label>` : `<span class="v">${rs(p.price)}</span>`}</div>`).join("")}</div>`;
  }).join("");
}
const dkey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const payOf = (id) => S.payments.find((x) => x.bookingId === id) || { amount: 0, method: "", status: "unpaid" };
const BF = { when: "all", status: "" };
function lowStock() { const out = [];
  for (const p of S.products) { if (p.status === "hidden") continue; for (const r of S.inventory.filter((x) => x.productId === p.id)) { const a = r.physicalStock - r.reservedStock; if (a <= LOW) out.push({ p, r, a }); } }
  return out.sort((x, y) => x.a - y.a); }
function renderOwner() {
  if (!isOwner()) return;
  const s = S.settings;
  if (!SETDIRTY) fillSettings();
  $("#loginNameNow").textContent = s.brand; $("#dashHi").textContent = "Welcome" + (s.ownerName ? " " + s.ownerName.split(" ")[0] : "") + " 👋 What would you like to do today?";
  const t0 = new Date(), tk = dkey(t0), nowK = tk + "T" + t0.toTimeString().slice(0, 5), mk = tk.slice(0, 7);
  const act = S.bookings.filter((b) => ["pending", "confirmed"].includes(b.status)), today = act.filter((b) => String(b.time).slice(0, 10) === tk).length, up = act.filter((b) => String(b.time) >= nowK && String(b.time).slice(0, 10) !== tk).length;
  const paid = S.payments.filter((x) => x.status === "paid" && x.paidAt), pday = paid.filter((x) => dkey(new Date(x.paidAt)) === tk).reduce((a, x) => a + x.amount, 0), pmon = paid.filter((x) => dkey(new Date(x.paidAt)).slice(0, 7) === mk).reduce((a, x) => a + x.amount, 0);
  const low = lowStock();
  $("#ownSum").innerHTML = `<a class="sum" data-go="bookings" data-when="today"><b>${today}</b><small>Today's bookings</small></a><a class="sum" data-go="bookings"><b>${up}</b><small>Upcoming bookings</small></a><a class="sum" data-go="bookings"><b>${S.bookings.filter((b) => !b.seen).length}</b><small>New</small></a><a class="sum money" data-go="bookings"><b>${rs(pday)}</b><small>Paid today</small></a><a class="sum money" data-go="bookings"><b>${rs(pmon)}</b><small>Paid this month</small></a><a class="sum${low.length ? " warn" : ""}" data-go="stock"><b>${low.length}</b><small>Low stock</small></a>`;
  $("#lowCount").textContent = low.length; $("#lowCount").hidden = !low.length;
  $("#lowBox").hidden = !low.length;
  $("#lowBox").innerHTML = `<h4>⚠️ Low stock <small class="muted">(${LOW} or fewer left)</small></h4>` + low.slice(0, 6).map(({ p, r, a }) => `<button type="button" class="lowrow" data-stock-go="${esc(p.id)}"><span>${esc(p.name)}${r.size || r.colour ? ` <small>${esc([r.size, r.colour].filter(Boolean).join(" / "))}</small>` : ""}</span><b class="${a <= 0 ? "out" : ""}">${a <= 0 ? "Sold out" : a + " left"}</b></button>`).join("") + (low.length > 6 ? `<button type="button" class="link" data-go2="stock">View ${low.length - 6} more</button>` : "");
  // report: this month
  { const mb = S.bookings.filter((b) => String(b.createdAt || b.created ? dkey(new Date(b.createdAt || b.created)) : "").slice(0, 7) === mk), cnt = {};
    mb.filter((b) => b.productSnapshot && b.status !== "cancelled").forEach((b) => { const k = b.productSnapshot.name; cnt[k] = (cnt[k] || 0) + (b.quantity || 1); });
    const top = Object.entries(cnt).sort((x, y) => y[1] - x[1]).slice(0, 3);
    $("#reportBox").hidden = false;
    $("#reportBox").innerHTML = `<h4>📈 This month's report</h4><div class="rep"><div><b>${mb.length}</b><small>Bookings</small></div><div><b>${mb.filter((b) => b.status === "picked_up").length}</b><small>Picked up</small></div><div><b>${rs(pmon)}</b><small>Paid</small></div></div>${top.length ? `<p class="hint"><b>Top products:</b> ${top.map(([n, q], i) => `${i + 1}. ${esc(n)} (${q})`).join(" · ")}</p>` : '<p class="hint">No product bookings yet.</p>'}`; }
  const nNew = S.bookings.filter((b) => !b.seen).length; $("#bkCount").textContent = nNew + " New"; $("#bkCount").hidden = !nNew;
  renderBookings(); renderStock(); renderGrahak();
  $("#opCount").textContent = "(" + S.products.length + " products)";
  const pf = $("#ownPriceForm"), keep = {}; $$("#ownerProducts input[type=number]").forEach((x) => { const p = S.products.find((q) => q.id === x.name); if (p && Number(x.value) !== p.price) keep[x.name] = x.value; });
  $("#ownerProducts").innerHTML = S.products.length ? CATS.concat([...new Set(S.products.map((p) => p.cat))].filter((c) => !CATS.includes(c))).map((c) => { const ps = S.products.filter((p) => p.cat === c); if (!ps.length) return "";
    return `<h4 class="op-cat">${esc(c)}</h4>` + ps.map((p) => `<div class="op"><img src="${esc(p.img)}" alt=""><div class="t"><b>${esc(p.name)}</b><small>Left: ${p.stock}${p.status === "hidden" ? ' · <span class="pst">🙈 Hidden</span>' : p.status === "out_of_stock" ? ' · <span class="pst">⛔ Out of stock</span>' : ""}</small><span class="tgl"><button type="button" class="tg${p.tag === "new" ? " on" : ""}" data-tag="new" data-pid="${esc(p.id)}" aria-pressed="${p.tag === "new"}">✨ New</button><button type="button" class="tg${p.tag === "best" ? " on" : ""}" data-tag="best" data-pid="${esc(p.id)}" aria-pressed="${p.tag === "best"}">🔥 Best</button></span></div><div class="op-act"><label class="op-sel"><input type="checkbox" data-sel="${esc(p.id)}"${SEL.has(p.id) ? " checked" : ""} aria-label="Select ${esc(p.name)}"></label><label class="op-pr">₹<input type="number" min="0" inputmode="numeric" name="${esc(p.id)}" value="${keep[p.id] ?? p.price}" aria-label="Price ${esc(p.name)}"></label><button type="button" class="btn small ghost" data-edit="${esc(p.id)}" aria-label="Edit ${esc(p.name)}">✏️ Edit</button><button type="button" class="btn small del" data-del="${esc(p.id)}" aria-label="Delete ${esc(p.name)}">🗑️ Delete</button></div></div>`).join(""); }).join("") : `<div class="soon own"><span class="soon-ic" aria-hidden="true">🛍️</span><h3>No products yet — tap Add Product</h3><p>Your store is empty. Add your first article with a photo, price and sizes.</p><button type="button" class="btn gold" data-go2="add">➕ Add Product</button></div>`;
  $("#ownPriceForm").classList.toggle("noprod", !S.products.length);
  for (const id of [...SEL]) if (!S.products.some((p) => p.id === id)) SEL.delete(id); drawSel();
  void pf;
}
function bkWhenOk(b) { if (BF.when === "all") return true; const t = new Date(); t.setHours(0, 0, 0, 0); const d = String(b.time).slice(0, 10);
  if (BF.when === "today") return d === dkey(t); const k = new Date(t); k.setDate(k.getDate() + 1); if (BF.when === "tomorrow") return d === dkey(k);
  const e = new Date(t); e.setDate(e.getDate() + 7); return d >= dkey(t) && d < dkey(e); }
function renderBookings() {
  $$("#bkWhen .chip").forEach((c) => c.classList.toggle("on", c.dataset.when === BF.when)); $("#bkStatus").value = BF.status;
  const bks = [...S.bookings].filter((b) => bkWhenOk(b) && (!BF.status || b.status === BF.status));
  bks.sort((x, y) => BF.when === "all" ? (y.createdAt || y.created || 0) - (x.createdAt || x.created || 0) : String(x.time).localeCompare(String(y.time)));
  $("#bkList").innerHTML = bks.length ? bks.map((b) => { const ps = b.productSnapshot, py = payOf(b.id), isNew = !b.seen || NEWSHOWN.has(b.id), open = ["pending", "confirmed"].includes(b.status);
    return `<div class="bk st-${b.status}${isNew ? " isnew" : ""}"><div class="bk-h"><b>${isNew ? '<span class="newtag">New</span> ' : ""}${esc(b.name)}</b><span class="spill s-${b.status}">${ST_LBL[b.status] || esc(b.status)}</span></div>
    ${ps ? `<div class="snap">${ps.image ? `<img src="${esc(ps.image)}" alt="" loading="lazy">` : ""}<div><b>${esc(ps.name)}</b><small>${[ps.size && "Size " + esc(ps.size), ps.colour && esc(ps.colour)].filter(Boolean).join(" · ")}</small><small>${b.quantity} × ${rs(ps.price)} = <b>${rs(b.totalAmount)}</b></small></div></div>` : `<div class="snap none">👕 Shop visit / trial${b.note ? " · " + esc(b.note) : ""}</div>`}
    <small>🕘 Pickup: <b>${esc(fmtTime(b.time))}</b></small>${b.phone ? `<small>📞 <a href="tel:${esc(b.phone)}">${esc(b.phone)}</a></small>` : ""}<small class="muted">Booked: ${new Date(b.createdAt || b.created).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}</small>
    <div class="payrow"><span class="ppill p-${py.status}">${py.status === "paid" ? "💰 Paid " + rs(py.amount) + " · " + (PM_LBL[py.method] || "") : py.status === "refunded" ? "↩️ Refunded" : "Unpaid" + (b.totalAmount ? " · " + rs(b.totalAmount) : "")}</span>
      ${py.status === "paid" ? `<button class="btn tiny ghost" data-pay="${esc(b.id)}" data-pst="unpaid">Undo</button><button class="btn tiny ghost" data-pay="${esc(b.id)}" data-pst="refunded">Refund</button>` : `<span class="paym" hidden data-paym="${esc(b.id)}"><button class="btn tiny" data-pay="${esc(b.id)}" data-meth="cash">Cash</button><button class="btn tiny" data-pay="${esc(b.id)}" data-meth="upi">UPI</button><button class="btn tiny" data-pay="${esc(b.id)}" data-meth="card">Card</button></span><button class="btn tiny gold" data-payopen="${esc(b.id)}">Mark paid</button>`}</div>
    <div class="acts">${b.status === "pending" ? `<button class="btn small" data-bk-st="${esc(b.id)}" data-st="confirmed">Confirm</button>` : ""}${open ? `<button class="btn small gold" data-bk-st="${esc(b.id)}" data-st="picked_up">Picked up ✓</button><button class="btn small ghost" data-bk-st="${esc(b.id)}" data-st="cancelled">Cancel</button><button class="btn small ghost" data-bk-st="${esc(b.id)}" data-st="no_show">No-show</button>` : `<button class="btn small ghost" data-bk-st="${esc(b.id)}" data-st="confirmed">↺ Back to confirmed</button>`}${b.phone ? `<a class="btn small ghost" href="https://wa.me/${esc(waNum(b.phone))}" target="_blank" rel="noopener">WhatsApp</a>` : ""}<button class="btn small danger" data-bk-del="${esc(b.id)}">Delete</button></div></div>`; }).join("")
    : `<p class="muted">${S.bookings.length ? "No bookings match this filter." : "No bookings yet."}</p>`;
}
const SQ = { q: "" }, STOPEN = new Set();
function renderStock() {
  const q = SQ.q.trim().toLowerCase(), ps = S.products.filter((p) => !q || (p.name + " " + p.cat).toLowerCase().includes(q));
  $("#stockList").innerHTML = ps.map((p) => { const rows = S.inventory.filter((r) => r.productId === p.id), ph = rows.reduce((a, r) => a + r.physicalStock, 0), rv = rows.reduce((a, r) => a + r.reservedStock, 0), low = rows.some((r) => r.physicalStock - r.reservedStock <= LOW);
    const cell = (r) => r ? `<label class="stc${r.physicalStock - r.reservedStock <= 0 ? " out" : r.physicalStock - r.reservedStock <= LOW ? " low" : ""}"><input type="number" min="${r.reservedStock}" inputmode="numeric" data-sv="${esc(r.variantId)}" value="${r.physicalStock}" aria-label="Stock ${esc([r.size, r.colour].filter(Boolean).join(" ") || p.name)}"><small>${r.reservedStock ? "R " + r.reservedStock + " · " : ""}left ${r.physicalStock - r.reservedStock}</small></label>` : "<span>–</span>";
    const find = (s, c) => rows.find((r) => r.variantId === vidOf(s, c));
    let grid;
    if (p.sizes.length && p.colours.length) grid = `<div class="sgrid" style="--cols:${p.colours.length}"><span></span>${p.colours.map((c) => `<span class="gh">${esc(c)}</span>`).join("")}${p.sizes.map((s) => `<span class="gh">${esc(s)}</span>` + p.colours.map((c) => cell(find(s, c))).join("")).join("")}</div>`;
    else if (p.sizes.length || p.colours.length) { const xs = p.sizes.length ? p.sizes : p.colours; grid = `<div class="sgrid" style="--cols:1"><span></span><span class="gh">Stock</span>${xs.map((x) => `<span class="gh">${esc(x)}</span>` + cell(p.sizes.length ? find(x, "") : find("", x))).join("")}</div>`; }
    else grid = `<div class="sgrid one">${cell(find("", ""))}</div>`;
    return `<details class="stp" data-stp="${esc(p.id)}" ${STOPEN.has(p.id) ? "open" : ""}><summary><img src="${esc(p.img)}" alt=""><span><b>${esc(p.name)}</b><small>In stock ${ph} · Reserved ${rv} · Available ${ph - rv}</small></span>${low ? '<i class="lowdot">Low</i>' : ""}</summary>
      <form class="stform" data-stform="${esc(p.id)}">${grid}<div class="row2"><button class="btn small" type="submit">💾 Save stock</button><button class="btn small ghost" type="button" data-edit="${esc(p.id)}">✏️ Edit sizes/colours</button></div><p class="formmsg" role="status"></p></form></details>`; }).join("") || '<p class="muted">No products yet. Add a product first, then set its stock here.</p>';
}
const GQ = { q: "" };
function renderGrahak() {
  const q = GQ.q.trim().toLowerCase(), linked = new Set(S.customers.map((c) => (c.account || "").toLowerCase()).filter(Boolean));
  const list = S.customers.map((c) => ({ ...c, bks: S.bookings.filter((b) => b.customerId === c.customerId) }))
    .concat(S.accounts.filter((a) => !linked.has(a.name.toLowerCase()) && !S.customers.some((c) => c.name.toLowerCase() === a.name.toLowerCase())).map((a) => ({ customerId: "", name: a.name, mobile: "", account: a.name, createdAt: a.created, bks: [] })))
    .filter((c) => !q || (c.name + " " + c.mobile).toLowerCase().includes(q))
    .sort((x, y) => y.bks.length - x.bks.length || (y.createdAt || 0) - (x.createdAt || 0));
  $("#gCount").textContent = "(" + list.length + ")";
  $("#gList").innerHTML = list.length ? list.map((c) => { const spent = c.bks.reduce((a, b) => { const py = payOf(b.id); return a + (py.status === "paid" ? py.amount : 0); }, 0);
    return `<details class="gc"><summary><span class="gav">${esc((c.name || "?").charAt(0).toUpperCase())}</span><span><b>${esc(c.name)}</b><small>${c.mobile ? esc(c.mobile) + " · " : ""}${c.bks.length} booking${spent ? " · " + rs(spent) + " paid" : ""}${c.account ? " · 👤 account" : ""}</small></span>${c.mobile ? `<a class="btn tiny gold" href="tel:+91${esc(c.mobile)}" aria-label="Call ${esc(c.name)}">📞 Call</a>` : ""}</summary>
      <div class="gh-list">${c.bks.length ? c.bks.map((b) => `<div class="ghb"><span>${esc(fmtTime(b.time))}</span><span>${b.productSnapshot ? esc(b.productSnapshot.name) + " × " + b.quantity + " · " + rs(b.totalAmount) : "Shop visit"}</span><span class="spill s-${b.status}">${ST_LBL[b.status] || ""}</span></div>`).join("") : '<p class="muted">No bookings yet.</p>'}
      ${c.customerId ? `<button type="button" class="btn tiny danger" data-cdel="${esc(c.customerId)}">Remove customer</button>` : ""}</div></details>`; }).join("") : '<p class="muted">No customers yet.</p>';
}
const waNum = (p) => { let w = String(p).replace(/\D/g, ""); if (w.length === 10) w = "91" + w; return w; };
function fmtTime(t) { const mt = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(t || ""); const d = mt ? new Date(+mt[1], mt[2] - 1, +mt[3], +mt[4], +mt[5]) : new Date(t); return isNaN(d) ? t : d.toLocaleString("en-IN", { weekday: "short", day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit", hour12: true }); }
function renderAll() { renderBrand(); renderAccount(); renderHome(); renderPrices(); renderWish(); renderOwner(); route(); }

function route() {
  if (ADMIN_PAGE) { ADMIN_PAGE = false; renderAdminPage(); }
  let h = decodeURIComponent(location.hash.slice(1)) || "home";
  if (h === "owner" && !isOwner()) { if (!S.loaded && S.token) return; h = "home"; }
  $$(".view").forEach((v) => (v.hidden = true));
  let toShop = false;
  if (CATS.includes(h) || h === "shop") { if (h !== "shop") { F.cat = h; renderShop(); } h = "home"; toShop = true; }
  ($("#v-" + h) || $("#v-home")).hidden = false;
  if (!$("#v-" + h)) h = "home";
  $$("#tabs a").forEach((a) => a.classList.toggle("on", a.dataset.tab === h));
  document.body.classList.toggle("owner-mode", h === "owner"); if (S.loaded) document.body.classList.remove("dash-loading");
  $("#dashFab").hidden = !(isOwner() && h !== "owner");
  if (toShop) scrollShop();
  const on = $("#tabs a.on"); if (on) on.scrollIntoView({ inline: "center", block: "nearest" });
}
window.addEventListener("hashchange", () => { window.scrollTo(0, 0); route(); });

async function load() {
  try { const d = await api("/data"); S.settings = d.settings; S.products = d.products; S.me = d.me; if (d.inventory) S.inventory = d.inventory; S.loaded = true; if (!d.me && S.token) setSession("", null); }
  catch (e) { toast(e.message); S.loaded = true; }
  if (isOwner()) { await loadBookings(); loadLoginSet(); }
  renderAll(); if (isOwner()) newToast();
}
function takeBundle(d) { if (d.bookings) S.bookings = d.bookings; if (d.payments) S.payments = d.payments; if (d.customers) S.customers = d.customers; if (d.inventory) S.inventory = d.inventory; if (d.accounts) S.accounts = d.accounts; if (d.users != null) S.users = d.users; if (d.products) S.products = d.products; }
async function loadBookings() { try { takeBundle(await api("/customers")); } catch (e) { toast(e.message); } }

// ---- product detail: gallery, size, colour, qty -> reserve & pickup ----
const PD = { p: null, size: "", colour: "", qty: 1, img: 0 };
const pdAvail = () => { const p = PD.p; if (!p || p.status === "out_of_stock") return 0; const a = p.avail || {};
  if ((p.sizes.length && !PD.size) || (p.colours.length && !PD.colour)) return null; return a[vidOf(p.sizes.length ? PD.size : "", p.colours.length ? PD.colour : "")] ?? 0; };
const optAvail = (size, colour) => { const p = PD.p, a = p.avail || {};
  // any variant matching the partial choice still has stock?
  const ss = p.sizes.length ? (size ? [size] : p.sizes) : [""], cc = p.colours.length ? (colour ? [colour] : p.colours) : [""];
  return ss.some((s) => cc.some((c) => (a[vidOf(s, c)] || 0) > 0)); };
function drawPD() {
  const p = PD.p, imgs = p.images && p.images.length ? p.images : p.img ? [p.img] : [], av = pdAvail(), oos = isOOS(p);
  if (av != null && PD.qty > Math.max(1, av)) PD.qty = Math.max(1, av);
  const lowTxt = av == null ? "" : av <= 0 ? '<span class="stock out">This size/colour is sold out</span>' : av <= 5 ? `<span class="stock low">Only ${av} left</span>` : `<span class="stock">Available: ${av}</span>`;
  const need = [p.sizes.length && !PD.size && "size", p.colours.length && !PD.colour && "colour"].filter(Boolean);
  $("#pdBody").innerHTML = `<div class="pd-img"><div class="gal" id="pdGal">${imgs.map((u, i) => `<img src="${esc(u)}" alt="${esc(p.name)} photo ${i + 1}" ${i ? 'loading="lazy"' : ""}>`).join("")}</div>${p.tag && TAGS[p.tag] ? `<span class="tag t-${p.tag}">${TAGS[p.tag]}</span>` : ""}${imgs.length > 1 ? `<div class="dots">${imgs.map((_, i) => `<button type="button" class="dot${i === PD.img ? " on" : ""}" data-gi="${i}" aria-label="Photo ${i + 1}"></button>`).join("")}</div>` : ""}</div>
  ${imgs.length > 1 ? `<div class="gthumbs pdt">${imgs.map((u, i) => `<button type="button" class="gth${i === PD.img ? " on" : ""}" data-gi="${i}"><img src="${esc(u)}" alt=""></button>`).join("")}</div>` : ""}
  <div class="in"><span class="cat">${esc(p.cat)}</span><h3>${esc(p.name)}</h3>${priceHTML(p, true)}${oos ? stockTxt(0) : ""}
  ${p.sizes.length ? `<div class="opt"><b>Size${PD.size ? ": " + esc(PD.size) : ""}</b><div class="optc">${p.sizes.map((s) => { const ok = !oos && optAvail(s, PD.colour); return `<button type="button" class="oc${PD.size === s ? " on" : ""}" data-size="${esc(s)}" ${ok ? "" : "disabled"}>${esc(s)}</button>`; }).join("")}</div></div>` : ""}
  ${p.colours.length ? `<div class="opt"><b>Colour${PD.colour ? ": " + esc(PD.colour) : ""}</b><div class="optc">${p.colours.map((c) => { const ok = !oos && optAvail(PD.size, c); return `<button type="button" class="oc col${PD.colour === c ? " on" : ""}" data-colour="${esc(c)}" ${ok ? "" : "disabled"}><i style="background:${esc(c.toLowerCase().replace(/[^a-z]/g, ""))}"></i>${esc(c)}</button>`; }).join("")}</div></div>` : ""}
  ${oos ? "" : `<div class="opt qrow"><b>Quantity</b><div class="qty"><button type="button" data-q="-1" aria-label="Decrease" ${PD.qty <= 1 ? "disabled" : ""}>−</button><output id="pdQty">${PD.qty}</output><button type="button" data-q="1" aria-label="Increase" ${av == null || PD.qty >= av ? "disabled" : ""}>+</button></div>${lowTxt}</div>
  <div class="pd-tot"><span>Total</span><b>${rs(p.price * PD.qty)}</b></div>`}
  ${p.desc ? `<p class="desc">${esc(p.desc)}</p>` : ""}
  <p class="pd-note">🛍️ Reserve now, pick up at the store. Pay at the store (Cash / UPI / Card).</p>
  <button class="btn gold full" type="button" id="pdBook" ${oos || av === 0 ? "disabled" : ""}>${oos ? "Out of stock" : need.length ? "Choose " + need.join(" and ") + " first" : "🛍️ Reserve & pick up"}</button>
  <button class="btn ghost full" type="button" id="pdWish">${WL.get().includes(p.id) ? "❤️ In your wishlist" : "🤍 Add to wishlist"}</button></div>`;
  const g = $("#pdGal"); if (g && PD.img) g.scrollLeft = g.clientWidth * PD.img;
  if (g) g.onscroll = () => { const i = Math.round(g.scrollLeft / (g.clientWidth || 1)); if (i !== PD.img) { PD.img = i; $$("#pdBody [data-gi]").forEach((d) => d.classList.toggle("on", +d.dataset.gi === i)); } };
}
function openPD(p) { PD.p = p; PD.qty = 1; PD.img = 0;
  PD.size = p.sizes.length === 1 ? p.sizes[0] : ""; PD.colour = p.colours.length === 1 ? p.colours[0] : "";
  drawPD(); $("#prodDlg").showModal(); }
document.addEventListener("click", (e) => {
  const w = e.target.closest("[data-wl]"); if (w) { e.preventDefault(); e.stopPropagation(); toggleWish(w.dataset.wl); return; }
  const c = e.target.closest(".pcard"); if (!c || c.classList.contains("sk")) return;
  const p = S.products.find((x) => x.id === c.dataset.pid); if (p) openPD(p);
});
$("#pdBody").addEventListener("click", (e) => {
  const t = e.target.closest("button"); if (!t || t.disabled) return; const p = PD.p;
  if (t.dataset.size !== undefined) { PD.size = PD.size === t.dataset.size ? "" : t.dataset.size; if (PD.colour && !optAvail(PD.size, PD.colour)) PD.colour = ""; PD.qty = 1; drawPD(); }
  else if (t.dataset.colour !== undefined) { PD.colour = PD.colour === t.dataset.colour ? "" : t.dataset.colour; if (PD.size && !optAvail(PD.size, PD.colour)) PD.size = ""; PD.qty = 1; drawPD(); }
  else if (t.dataset.q) { PD.qty = Math.max(1, PD.qty + Number(t.dataset.q)); drawPD(); }
  else if (t.dataset.gi !== undefined) { PD.img = +t.dataset.gi; const g = $("#pdGal"); g.scrollTo({ left: g.clientWidth * PD.img, behavior: "smooth" }); $$("#pdBody [data-gi]").forEach((d) => d.classList.toggle("on", +d.dataset.gi === PD.img)); }
  else if (t.id === "pdWish") { toggleWish(p.id); drawPD(); }
  else if (t.id === "pdBook") {
    const av = pdAvail(); if (av == null) { toast("Choose a size / colour first"); return; }
    $("#prodDlg").close(); setBookSel({ p, size: p.sizes.length ? PD.size : "", colour: p.colours.length ? PD.colour : "", qty: PD.qty }); location.hash = "booking";
  }
});
$("#pdClose").onclick = () => $("#prodDlg").close();
$("#prodDlg").addEventListener("click", (e) => { if (e.target.id === "prodDlg") $("#prodDlg").close(); });
function toggleWish(id) { const a = WL.get(), i = a.indexOf(id); if (i >= 0) a.splice(i, 1); else a.unshift(id); WL.set(a); toast(i >= 0 ? "Removed from wishlist" : "❤️ Added to wishlist"); renderHome(); renderWish(); }
function renderWish() { const ids = WL.get(), ps = ids.map((id) => S.products.find((p) => p.id === id)).filter(Boolean);
  $("#wlN").textContent = ps.length; $("#wlN").hidden = !ps.length;
  $("#wlGrid").innerHTML = ps.length ? ps.map(card).join("") : `<div class="empty" style="grid-column:1/-1">Your wishlist is empty. Tap 🤍 on a product to save it.<br><a class="link" href="#shop">View collection</a></div>`; }

// ---- auth dialog ----
let mode = "login";
function openAuth(m) {
  if (S.me && !m) { if (isOwner()) { openOwnerPanel(); return; } if (confirm("Log out?")) logout(); return; }
  setMode(m || "login"); msg($("#authMsg"), ""); $("#aPass").value = ""; $("#authDlg").showModal(); setTimeout(() => $("#aName").focus(), 50);
}
function setMode(m) {
  mode = m; $$("#authDlg .seg button").forEach((b) => b.classList.toggle("on", b.dataset.mode === m));
  $("#authTitle").textContent = "Sign up / Login";
  $("#authSub").textContent = { login: "Log in to your account", signup: "Create a new account" }[m];
  $("#aPass").autocomplete = m === "signup" ? "new-password" : "current-password";
  $("#aPass").previousSibling.textContent = m === "signup" ? "Create password" : "Password";
  $("#authGo").textContent = { login: "Login", signup: "Sign up" }[m];
  $("#authHint").textContent = { login: 'New here? Tap "Sign up" above.', signup: "Choose any password (at least 4 characters)." }[m];
}
$$("#authDlg .seg button").forEach((b) => (b.onclick = () => { setMode(b.dataset.mode); msg($("#authMsg"), ""); }));
$("#accountBtn").onclick = () => openAuth();
document.addEventListener("click", (e) => { const o = e.target.closest("[data-open]"); if (o) openAuth("login"); });
async function doAuth() {
  const name = $("#aName").value.trim(), password = $("#aPass").value, b = $("#authGo");
  if (!name || !password) return msg($("#authMsg"), "Please enter both name and password");
  b.disabled = true;
  try {
    const d = await api(mode === "signup" ? "/signup" : "/login", { method: "POST", body: { name, password } });
    $("#authDlg").close(); setSession(d.token, d.me);
    if (isOwner()) { await loadBookings(); loadLoginSet(); renderAll(); openOwnerPanel(); toast("Owner panel opened ✓"); newToast(); }
    else toast(mode === "signup" ? "Account created, welcome " + d.me.name + "!" : "Welcome back, " + d.me.name + "!");
  } catch (e) { msg($("#authMsg"), e.message); } finally { b.disabled = false; }
}
$("#authGo").onclick = doAuth;
$("#aPass").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); doAuth(); } });
async function logout() { try { await api("/logout", { method: "POST" }); } catch {} setSession("", null); if (location.pathname !== "/") location.replace("/"); else location.hash = "home"; toast("Logged out"); }

// ---- shortcuts: /admin and 5 quick taps on the shop logo/name open the same Sign up / Login popup ----
let taps = [];
$(".logo").addEventListener("click", () => {
  const now = Date.now(); taps = taps.filter((t) => now - t < 2500); taps.push(now);
  if (taps.length >= 5) { taps = []; if (isOwner()) openOwnerPanel(); else openAuth("login"); }
});
function renderAdminPage() {
  history.replaceState(null, "", "/" + location.hash);
  if (isOwner()) { history.replaceState(null, "", "/#owner"); return; }
  setTimeout(() => { if (!$("#authDlg").open && !S.me) openAuth("login"); }, 0);
}
$("#logoutBtn2").onclick = logout; $("#logoutBtn3").onclick = logout;
let PANE = "prices";
function showPane(p, scroll) {
  PANE = p; $$(".ownbtn").forEach((b) => b.classList.toggle("on", b.dataset.pane === p));
  $$(".ownpane").forEach((x) => (x.hidden = x.id !== "pane-" + p));
  if (scroll) $("#pane-" + p).scrollIntoView({ behavior: "smooth", block: "start" });
}
const NEWSHOWN = new Set();
async function markSeen() { const ids = S.bookings.filter((b) => !b.seen).map((b) => b.id); if (!ids.length) return; ids.forEach((id) => NEWSHOWN.add(id));
  try { const d = await api("/bookings/seen", { method: "POST" }); S.bookings = S.bookings.map((b) => ({ ...b, seen: true })); void d; } catch {} renderOwner(); }
$("#ownSum").addEventListener("click", (e) => { const a = e.target.closest("[data-go]"); if (!a) return; if (a.dataset.when) BF.when = a.dataset.when; $("#ob" + ({ bookings: "Bookings", stock: "Stock", prices: "Prices" }[a.dataset.go] || "Prices")).click(); });
$$(".ownbtn").forEach((b) => (b.onclick = async () => { showPane(b.dataset.pane, true); if (["bookings", "grahak", "stock"].includes(b.dataset.pane)) { await loadBookings(); renderOwner(); if (b.dataset.pane === "bookings") markSeen(); } }));
function newToast() { const n = S.bookings.filter((b) => !b.seen).length; if (n) setTimeout(() => toast("📅 " + n + " new booking(s)! Tap View Bookings"), 900); }
function openOwnerPanel() { if (location.hash !== "#owner") location.hash = "owner"; else route(); showPane(PANE); window.scrollTo(0, 0); }

// ---- settings ----
const SKEYS = ["brand", "tagline", "ownerName", "logo", "phone", "whatsapp", "email", "address", "mapsUrl", "upi", "gst", "deliveryAreas", "deliveryCharge", "returnPolicy", "instagram", "facebook", "offerText", "offerSub", "reviews", "slotOpen", "slotClose", "holidays"];
let SETDIRTY = false;
function fillSettings() {
  const s = S.settings, f = $("#setForm");
  for (const k of SKEYS) f[k].value = s[k] ?? "";
  f.offerOn.checked = s.offerOn !== false; f.delivery.checked = !!s.delivery; f.alteration.checked = !!s.alteration;
  const pm = s.payModes || { cash: true, upi: true }; f.pmCash.checked = !!pm.cash; f.pmUpi.checked = !!pm.upi; f.pmCard.checked = !!pm.card;
  f.slotLen.value = String(s.slotLen || 30); f.slotOpen.value = s.slotOpen || "10:00"; f.slotClose.value = s.slotClose || "20:00";
  const h = hoursArr() || Array.from({ length: 7 }, () => ({ o: "10:00", c: "21:00", x: false }));
  h.forEach((v, i) => { f["ho" + i].value = v.o; f["hc" + i].value = v.c; f["hx" + i].checked = !!v.x; });
  if (f.whatsapp.value.length === 12 && f.whatsapp.value.startsWith("91")) f.whatsapp.value = f.whatsapp.value.slice(2);
  drawLogo(); drawHol(); hoursState(); $("#brandHint").textContent = "Current login: \"" + s.brand + "\" + password";
}
function hoursState() { const f = $("#setForm"); for (let i = 0; i < 7; i++) { const x = f["hx" + i].checked; f["ho" + i].disabled = x; f["hc" + i].disabled = x; f["ho" + i].closest(".hrow").classList.toggle("off", x); } }
function drawLogo() { const v = $("#setForm").logo.value; $("#logoPreview").hidden = !v; if (v) $("#logoPreview").src = v; $("#logoDel").hidden = !v; }
function drawHol() { const v = $("#setForm").holidays.value.match(/\d{4}-\d{2}-\d{2}/g) || [];
  $("#holList").innerHTML = v.length ? v.map((d) => `<span class="holc">${esc(new Date(d + "T00:00").toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }))}<button type="button" data-hol="${d}" aria-label="Remove">×</button></span>`).join("") : '<small class="muted">No holidays added</small>'; }
$("#setForm").addEventListener("input", (e) => { SETDIRTY = true; if (/^hx\d$/.test(e.target.name)) hoursState(); });
$("#hCopy").onclick = () => { const f = $("#setForm"); for (let i = 0; i < 7; i++) { f["ho" + i].value = f.ho1.value; f["hc" + i].value = f.hc1.value; } SETDIRTY = true; };
$("#holBtn").onclick = () => { const d = $("#holAdd").value, f = $("#setForm"); if (!d) { toast("Choose a date first"); return; } const v = new Set(f.holidays.value.match(/\d{4}-\d{2}-\d{2}/g) || []); v.add(d); f.holidays.value = [...v].sort().join(", "); $("#holAdd").value = ""; SETDIRTY = true; drawHol(); };
$("#holList").addEventListener("click", (e) => { const b = e.target.closest("[data-hol]"); if (!b) return; const f = $("#setForm"); f.holidays.value = (f.holidays.value.match(/\d{4}-\d{2}-\d{2}/g) || []).filter((d) => d !== b.dataset.hol).join(", "); SETDIRTY = true; drawHol(); });
$("#logoFile").addEventListener("change", async (e) => {
  const file = e.target.files[0]; if (!file) return;
  try { msg($("#setMsg"), "Uploading logo…", true); const data = await resizeImage(file, 400); const d = await api("/upload", { method: "POST", body: { data } }); $("#setForm").logo.value = d.url; SETDIRTY = true; drawLogo(); msg($("#setMsg"), "Logo ready ✓ Now tap Save settings", true); }
  catch (err) { msg($("#setMsg"), err.message); } finally { e.target.value = ""; }
});
$("#logoDel").onclick = () => { $("#setForm").logo.value = ""; SETDIRTY = true; drawLogo(); };
document.addEventListener("click", (e) => { const c = e.target.closest("[data-copy]"); if (!c) return; navigator.clipboard?.writeText(c.dataset.copy).then(() => toast("UPI ID copied ✓"), () => toast(c.dataset.copy)); });

// ---- booking ----
// custom date + time picker: month -> day -> time slot
const DT = (() => {
  const MON = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const MS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], WD = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const pad = (n) => String(n).padStart(2, "0"), AHEAD = 6;
  const toMin = (t, d) => { const mt = /^(\d{2}):(\d{2})$/.exec(t || ""); return mt ? +mt[1] * 60 + +mt[2] : d; };
  const SLOTSF = () => { const s = S.settings, a = toMin(s.slotOpen, 600), b = toMin(s.slotClose, 1200), st = [15, 30, 45, 60].includes(+s.slotLen) ? +s.slotLen : 30, out = []; for (let m = a; m <= b && out.length < 96; m += st) out.push(m); return out; };
  const dkey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const closedDay = (d) => String(S.settings.holidays || "").includes(dkey(d)) || !!(Array.isArray(S.settings.hours) && S.settings.hours[d.getDay()] && S.settings.hours[d.getDay()].x);
  const hm = (m) => { const h = Math.floor(m / 60), mi = m % 60; return `${h % 12 || 12}:${pad(mi)} ${h < 12 ? "AM" : "PM"}`; };
  const today = () => { const t = new Date(); t.setHours(0, 0, 0, 0); return t; };
  const nowMin = () => { const n = new Date(); return n.getHours() * 60 + n.getMinutes() + 15; };
  const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  const slotsFor = (d) => closedDay(d) ? [] : SLOTSF().filter((m) => !sameDay(d, today()) || m >= nowMin());
  const dayOk = (d) => d >= today() && slotsFor(d).length > 0;
  const box = $("#dtPick"), btn = $("#dtBtn"), val = $("#dtVal"), txt = $("#dtText");
  let view, pickDay = null, sel = null; // sel = {d: Date(day), m: minutes}
  function firstMonth() { const t = today(); return new Date(t.getFullYear(), t.getMonth(), 1); }
  function monthIdx(d) { const f = firstMonth(); return (d.getFullYear() - f.getFullYear()) * 12 + d.getMonth() - f.getMonth(); }
  function drawMonth() {
    const f = firstMonth(), sm = $("#dtpMonth"); sm.innerHTML = "";
    for (let i = 0; i <= AHEAD; i++) { const d = new Date(f.getFullYear(), f.getMonth() + i, 1); sm.add(new Option(MON[d.getMonth()] + " " + d.getFullYear(), i)); }
    const k = monthIdx(view); sm.value = k; $("#dtpPrev").disabled = k <= 0; $("#dtpNext").disabled = k >= AHEAD;
    const y = view.getFullYear(), mo = view.getMonth(), lead = new Date(y, mo, 1).getDay(), n = new Date(y, mo + 1, 0).getDate();
    let html = ""; for (let i = 0; i < lead; i++) html += "<span></span>";
    for (let dd = 1; dd <= n; dd++) {
      const d = new Date(y, mo, dd), ok = dayOk(d), on = sel && sameDay(sel.d, d), td = sameDay(d, today());
      html += `<button type="button" class="dtp-d${on ? " on" : ""}${td ? " td" : ""}${d >= today() && closedDay(d) ? " cl" : ""}" data-day="${dd}" ${ok ? "" : "disabled"}${d >= today() && closedDay(d) ? ' title="Store closed"' : ""}>${dd}</button>`;
    }
    $("#dtpDays").innerHTML = html;
  }
  function step(n) { $("#dtpStep1").hidden = n !== 1; $("#dtpStep2").hidden = n !== 2; $("#dtpTitle").textContent = n === 1 ? "Choose a month, then a date" : "Choose a time"; }
  function drawTimes() {
    $("#dtpDayLbl").textContent = `${WD[pickDay.getDay()]}, ${pickDay.getDate()} ${MS[pickDay.getMonth()]}`;
    $("#dtpTimes").innerHTML = SLOTSF().map((m) => { const ok = slotsFor(pickDay).includes(m), on = sel && sameDay(sel.d, pickDay) && sel.m === m;
      return `<button type="button" class="dtp-t${on ? " on" : ""}" data-min="${m}" ${ok ? "" : "disabled"}>${hm(m)}</button>`; }).join("");
  }
  function open() { view = sel ? new Date(sel.d.getFullYear(), sel.d.getMonth(), 1) : firstMonth(); step(1); drawMonth(); box.hidden = false; document.body.classList.add("dtp-lock"); }
  function close() { box.hidden = true; document.body.classList.remove("dtp-lock"); }
  function set(d, m) {
    sel = d ? { d, m } : null;
    val.value = d ? `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(Math.floor(m / 60))}:${pad(m % 60)}` : "";
    txt.textContent = d ? `${WD[d.getDay()]}, ${d.getDate()} ${MS[d.getMonth()]} ${d.getFullYear()}  ·  ${hm(m)}` : "Choose date and time";
    txt.className = d ? "dt-on" : "dt-ph";
  }
  btn.addEventListener("click", open);
  $("#dtpClose").onclick = close;
  box.addEventListener("click", (e) => { if (e.target === box) close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !box.hidden) close(); });
  $("#dtpPrev").onclick = () => { view = new Date(view.getFullYear(), view.getMonth() - 1, 1); drawMonth(); };
  $("#dtpNext").onclick = () => { view = new Date(view.getFullYear(), view.getMonth() + 1, 1); drawMonth(); };
  $("#dtpMonth").onchange = (e) => { const f = firstMonth(); view = new Date(f.getFullYear(), f.getMonth() + Number(e.target.value), 1); drawMonth(); };
  $("#dtpDays").addEventListener("click", (e) => { const b = e.target.closest("[data-day]"); if (!b || b.disabled) return; pickDay = new Date(view.getFullYear(), view.getMonth(), Number(b.dataset.day)); drawTimes(); step(2); });
  $("#dtpBack").onclick = () => { step(1); drawMonth(); };
  $("#dtpTimes").addEventListener("click", (e) => { const b = e.target.closest("[data-min]"); if (!b || b.disabled) return; set(pickDay, Number(b.dataset.min)); close(); btn.classList.remove("bad"); });
  return { get: () => val.value, valid: () => !!sel && sel.d >= today() && slotsFor(sel.d).includes(sel.m), clear: () => set(null), open };
})();
let BSEL = null;
function setBookSel(sel) { BSEL = sel && sel.p ? sel : null; const f = $("#bookForm"); f.note.value = "";
  const p = BSEL && BSEL.p, box = $("#bkSel");
  $("#v-booking .sec-head h2").textContent = BSEL ? "🛍️ Reserve & pickup" : "📅 Book a shop visit / trial";
  $("#bookGo").textContent = BSEL ? "Confirm Reservation" : "Confirm Booking";
  box.innerHTML = BSEL ? `<div class="selcard">${p.img ? `<img src="${esc(p.img)}" alt="">` : ""}<div><b>${esc(p.name)}</b><small>${[BSEL.size && "Size " + esc(BSEL.size), BSEL.colour && esc(BSEL.colour), "Qty " + BSEL.qty].filter(Boolean).join(" · ")}</small><span class="tot">${BSEL.qty} × ${rs(p.price)} = <b>${rs(p.price * BSEL.qty)}</b></span></div><button type="button" class="link" id="bkSelX">Remove</button></div><p class="hint">Pay at the store when you pick up. For a visit without a product, tap "Remove".</p>`
    : `<p class="hint selnone">Shop visit / trial only. To reserve a product, choose one from the <a class="link" href="#shop">collection</a>.</p>`;
  if (BSEL) $("#bkSelX").onclick = () => setBookSel(null);
}
$("#bookForm").addEventListener("submit", async (e) => {
  e.preventDefault(); const f = e.target, m = $("#bookMsg");
  if (!S.me) { msg(m, "Please log in / sign up first"); openAuth("login"); return; }
  const mob = f.phone.value.replace(/\D/g, "").replace(/^(91|0)(?=\d{10}$)/, "");
  if (mob.length !== 10) { msg(m, "Please enter a valid 10-digit mobile number"); f.phone.focus(); return; }
  if (!DT.valid()) { msg(m, "Please choose a date and time"); $("#dtBtn").classList.add("bad"); DT.open(); return; }
  const body = { name: f.name.value.trim(), phone: mob, time: DT.get(), note: f.note.value.trim() };
  if (BSEL) Object.assign(body, { productId: BSEL.p.id, size: BSEL.size, colour: BSEL.colour, quantity: BSEL.qty });
  const btn = f.querySelector("button[type=submit]"); btn.disabled = true;
  try {
    const d = await api("/bookings", { method: "POST", body });
    msg(m, (BSEL ? `Reserved ✅ ${BSEL.p.name} × ${BSEL.qty} (${rs(d.booking.totalAmount)}). Pickup: ` : "Booking confirmed ✅ ") + fmtTime(body.time), true); setBookSel(null); DT.clear();
    await reloadData(); if (isOwner()) { await loadBookings(); renderOwner(); }
  } catch (err) { msg(m, err.message); } finally { btn.disabled = false; }
});
async function reloadData() { try { const d = await api("/data"); S.settings = d.settings; S.products = d.products; if (d.inventory) S.inventory = d.inventory; renderHome(); renderPrices(); renderWish(); } catch {} }

// ---- prices ----
$("#priceForm").addEventListener("submit", async (e) => {
  e.preventDefault(); const prices = {};
  $$("#priceList input").forEach((i) => { const p = S.products.find((x) => x.id === i.name); if (p && Number(i.value) !== p.price) prices[i.name] = Number(i.value); });
  if (!Object.keys(prices).length) return msg($("#priceMsg"), "No prices changed", true);
  try { const d = await api("/prices", { method: "POST", body: { prices } }); S.products = d.products; renderAll(); msg($("#priceMsg"), Object.keys(prices).length + " price(s) saved ✓", true); toast("Prices saved ✓"); }
  catch (err) { msg($("#priceMsg"), err.message); }
});

$("#ownPriceForm").addEventListener("submit", async (e) => {
  e.preventDefault(); const prices = {}, m = $("#ownPriceMsg");
  $$("#ownerProducts input[type=number]").forEach((i) => { const p = S.products.find((x) => x.id === i.name); if (p && i.value !== "" && Number(i.value) !== p.price) prices[i.name] = Number(i.value); });
  if (!Object.keys(prices).length) return msg(m, "No prices changed", true);
  try { const d = await api("/prices", { method: "POST", body: { prices } }); S.products = d.products; $("#ownerProducts").innerHTML = ""; renderAll(); msg(m, Object.keys(prices).length + " price(s) saved ✓", true); toast("Prices saved ✓"); }
  catch (err) { msg(m, err.message); }
});

// ---- owner: products ----
let pendingImg = "";
function resizeImage(file, MAX = 900) {
  return new Promise((res, rej) => {
    const img = new Image(), u = URL.createObjectURL(file);
    img.onload = () => { const M = MAX, sc = Math.min(1, M / Math.max(img.width, img.height)); const c = document.createElement("canvas"); c.width = Math.round(img.width * sc); c.height = Math.round(img.height * sc);
      const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL("image/jpeg", 0.82)); };
    img.onerror = () => rej(new Error("This photo could not be opened. Please try another one")); img.src = u;
  });
}
let PIMGS = [];
const PF = { sizes: [], colours: [] };
function drawPF() {
  $("#prodThumbs").innerHTML = PIMGS.map((u, i) => `<span class="gth"><img src="${esc(u)}" alt="Photo ${i + 1}">${i === 0 ? '<em>Main</em>' : `<button type="button" data-pmain="${i}" aria-label="Make main photo">★</button>`}<button type="button" class="rm" data-prm="${i}" aria-label="Remove photo">×</button></span>`).join("") || '<small class="muted">No photos yet</small>';
  const extraS = PF.sizes.filter((x) => !SIZES.includes(x)), extraC = PF.colours.filter((x) => !COLOURS.includes(x));
  $("#sizeChips").innerHTML = SIZES.concat(extraS).map((s) => `<button type="button" class="oc${PF.sizes.includes(s) ? " on" : ""}" data-ps="${esc(s)}">${esc(s)}</button>`).join("");
  $("#colourChips").innerHTML = COLOURS.concat(extraC).map((c) => `<button type="button" class="oc col${PF.colours.includes(c) ? " on" : ""}" data-pc="${esc(c)}"><i style="background:${esc(c.toLowerCase().replace(/[^a-z]/g, ""))}"></i>${esc(c)}</button>`).join("");
  const n = Math.max(1, PF.sizes.length) * Math.max(1, PF.colours.length), edit = !!$("#prodForm").id.value;
  $("#stockLbl").hidden = edit; $("#stockHint").textContent = edit ? "To change stock, use the 📦 Stock section. New sizes/colours start at 0 stock." : `${n} variant(s) will be created, each with this stock. You can change each one later in 📦 Stock.`;
}
$("#sizeChips").addEventListener("click", (e) => { const b = e.target.closest("[data-ps]"); if (!b) return; const s = b.dataset.ps, i = PF.sizes.indexOf(s); i >= 0 ? PF.sizes.splice(i, 1) : PF.sizes.push(s); PF.sizes.sort((x, y) => (SIZES.indexOf(x) + 1 || 99) - (SIZES.indexOf(y) + 1 || 99)); drawPF(); });
$("#colourChips").addEventListener("click", (e) => { const b = e.target.closest("[data-pc]"); if (!b) return; const s = b.dataset.pc, i = PF.colours.indexOf(s); i >= 0 ? PF.colours.splice(i, 1) : PF.colours.push(s); drawPF(); });
$("#prodThumbs").addEventListener("click", (e) => { const r = e.target.closest("[data-prm]"), mn = e.target.closest("[data-pmain]");
  if (r) { PIMGS.splice(+r.dataset.prm, 1); drawPF(); } else if (mn) { const [x] = PIMGS.splice(+mn.dataset.pmain, 1); PIMGS.unshift(x); drawPF(); } });
const splitList = (v) => String(v || "").split(/[,/]+/).map((x) => x.trim()).filter(Boolean);
$("#prodFile").addEventListener("change", async (e) => {
  const files = [...e.target.files].slice(0, 8 - PIMGS.length), m = $("#prodMsg"); if (!files.length) { if (e.target.files.length) msg(m, "Maximum 8 photos"); return; }
  try { for (let i = 0; i < files.length; i++) { msg(m, `Uploading photo… (${i + 1}/${files.length})`, true); const data = await resizeImage(files[i]); const d = await api("/upload", { method: "POST", body: { data } }); PIMGS.push(d.url); drawPF(); }
    msg(m, files.length + " photo(s) ready ✓", true); }
  catch (err) { msg(m, err.message); } finally { e.target.value = ""; }
});
function resetProdForm() { const f = $("#prodForm"); f.reset(); f.id.value = ""; PIMGS = []; PF.sizes = []; PF.colours = []; $("#prodSubmit").textContent = "Add product"; $("#prodFormTitle").textContent = "➕ Add a new product"; $("#prodCancel").hidden = true; $("#prodDelete").hidden = true; f.stock.value = 5; drawPF(); }
$("#prodCancel").onclick = () => { resetProdForm(); msg($("#prodMsg"), ""); };
$("#prodForm").addEventListener("submit", async (e) => {
  e.preventDefault(); const f = e.target, m = $("#prodMsg");
  const sizes = [...PF.sizes, ...splitList(f.sizesExtra.value)], colours = [...PF.colours, ...splitList(f.coloursExtra.value)];
  const body = { name: f.name.value.trim(), cat: f.cat.value, price: Number(f.price.value), mrp: Number(f.mrp.value) || 0, desc: f.desc.value.trim(), sizes, colours, status: f.status.value, tag: f.tag.value, images: PIMGS };
  if (!f.id.value) body.stock = f.stock.value === "" ? 5 : Number(f.stock.value);
  try {
    const d = f.id.value ? await api("/products/" + f.id.value, { method: "PUT", body }) : await api("/products", { method: "POST", body });
    takeBundle(d); const was = f.id.value; resetProdForm(); renderAll(); msg(m, was ? "Product updated ✓" : "Product added ✓ It is now live in the shop.", true); toast("Saved ✓");
  } catch (err) { msg(m, err.message); }
});
const SEL = new Set();
function drawSel() { const b = $("#selBar"); if (!b) return; b.hidden = !SEL.size; $("#selN").textContent = SEL.size; $("#selDel").disabled = false; }
$("#ownerProducts").addEventListener("change", (e) => { const c = e.target.closest("[data-sel]"); if (!c) return; c.checked ? SEL.add(c.dataset.sel) : SEL.delete(c.dataset.sel); drawSel(); });
async function delProduct(id) { const p = S.products.find((x) => x.id === id); if (!p) return false; if (!confirm(`Delete "${p.name}"? This can't be undone.`)) return false;
  const d = await api("/products/" + p.id, { method: "DELETE" }); SEL.delete(p.id); takeBundle(d); renderAll(); toast(`"${p.name}" deleted`); return true; }
$("#prodDelete").onclick = async () => { const id = $("#prodForm").id.value; if (!id) return; try { if (await delProduct(id)) { resetProdForm(); msg($("#prodMsg"), ""); showPane("prices", true); } } catch (err) { msg($("#prodMsg"), err.message); } };
function editProduct(p) { const f = $("#prodForm");
  f.id.value = p.id; f.name.value = p.name; f.cat.value = p.cat; f.price.value = p.price; f.mrp.value = p.mrp || ""; f.desc.value = p.desc || ""; f.tag.value = p.tag || ""; f.status.value = p.status || "active";
  f.sizesExtra.value = ""; f.coloursExtra.value = ""; PIMGS = [...(p.images || [])]; PF.sizes = [...p.sizes]; PF.colours = [...p.colours]; drawPF();
  $("#prodSubmit").textContent = "Save changes"; $("#prodFormTitle").textContent = "✏️ Edit: " + p.name; $("#prodCancel").hidden = false; $("#prodDelete").hidden = false;
  showPane("add", true); msg($("#prodMsg"), ""); }
$("#bkWhen").addEventListener("click", (e) => { const c = e.target.closest("[data-when]"); if (c) { BF.when = c.dataset.when; renderBookings(); } });
$("#bkStatus").addEventListener("change", (e) => { BF.status = e.target.value; renderBookings(); });
$("#stQ").addEventListener("input", (e) => { SQ.q = e.target.value; renderStock(); });
$("#gQ").addEventListener("input", (e) => { GQ.q = e.target.value; renderGrahak(); });
$("#stockList").addEventListener("toggle", (e) => { const d = e.target.closest("[data-stp]"); if (d) d.open ? STOPEN.add(d.dataset.stp) : STOPEN.delete(d.dataset.stp); }, true);
$("#stockList").addEventListener("submit", async (e) => {
  e.preventDefault(); const f = e.target.closest("[data-stform]"); if (!f) return; const stock = {}, mm = f.querySelector(".formmsg");
  $$("[data-sv]", f).forEach((i) => (stock[i.dataset.sv] = Number(i.value)));
  try { const d = await api("/inventory/" + f.dataset.stform, { method: "PUT", body: { stock } }); takeBundle(d); STOPEN.add(f.dataset.stform); renderAll(); toast("Stock saved ✓"); }
  catch (err) { msg(mm, err.message); }
});
$("#v-owner").addEventListener("click", async (e) => {
  const t = e.target.closest("button"); if (!t) return;
  try {
    if (t.dataset.tag) { const p = S.products.find((x) => x.id === t.dataset.pid); if (!p) return; const nt = p.tag === t.dataset.tag ? "" : t.dataset.tag; t.disabled = true;
      const d = await api("/products/" + p.id, { method: "PUT", body: { tag: nt } }); takeBundle(d); renderAll(); toast(nt ? `${p.name}: ${TAGS[nt]} tag added ✓` : `${p.name}: tag removed ✓`); return; }
    if (t.dataset.edit) { const p = S.products.find((x) => x.id === t.dataset.edit); if (p) editProduct(p); return; }
    if (t.dataset.payopen) { const s = $(`[data-paym="${t.dataset.payopen}"]`); s.hidden = !s.hidden; t.textContent = s.hidden ? "Mark paid" : "Paid how?"; return; }
    if (t.dataset.pay) { t.disabled = true; const d = await api("/bookings/" + t.dataset.pay + "/pay", { method: "POST", body: t.dataset.meth ? { status: "paid", method: t.dataset.meth } : { status: t.dataset.pst } }); takeBundle(d); renderOwner(); toast(t.dataset.meth ? "Paid ✓ " + PM_LBL[t.dataset.meth] : "Payment updated ✓"); return; }
    if (t.dataset.bkSt) { t.disabled = true; const st = t.dataset.st; if (["cancelled", "no_show"].includes(st) && !confirm(st === "cancelled" ? "Cancel this booking? The reserved stock will be released." : "Mark as no-show? The reserved stock will be released.")) { t.disabled = false; return; }
      const d = await api("/bookings/" + t.dataset.bkSt, { method: "PUT", body: { status: st } }); takeBundle(d); await reloadData(); renderOwner(); toast(ST_LBL[st] + " ✓"); return; }
    if (t.dataset.cdel) { if (!confirm("Remove this customer from the list? (Their bookings will stay)")) return; const d = await api("/customers/" + t.dataset.cdel, { method: "DELETE" }); takeBundle(d); renderOwner(); toast("Customer removed"); return; }
    if (t.dataset.stockGo) { STOPEN.add(t.dataset.stockGo); showPane("stock", true); renderStock(); setTimeout(() => $(`[data-stp="${t.dataset.stockGo}"]`)?.scrollIntoView({ block: "center" }), 50); return; }
    if (t.dataset.go2) { showPane(t.dataset.go2, true); return; }
    if (false) {}
    else if (t.dataset.del) { await delProduct(t.dataset.del); }
    else if (t.id === "selDel") { const ps = S.products.filter((p) => SEL.has(p.id)); if (!ps.length) return; if (!confirm(`Delete ${ps.length} product(s)? This can't be undone.\n\n${ps.map((p) => "• " + p.name).join("\n")}`)) return; t.disabled = true; let d = null; for (const p of ps) { d = await api("/products/" + p.id, { method: "DELETE" }); SEL.delete(p.id); } if (d) takeBundle(d); renderAll(); toast(ps.length + " product(s) deleted"); }
    else if (t.id === "selClear") { SEL.clear(); renderAll(); }
    else if (t.dataset.bkDone) { const d = await api("/bookings/" + t.dataset.bkDone, { method: "PUT", body: { status: t.dataset.st } }); S.bookings = d.bookings; renderOwner(); }
    else if (t.dataset.bkDel) { if (!confirm("Delete this booking?")) return; const d = await api("/bookings/" + t.dataset.bkDel, { method: "DELETE" }); takeBundle(d); await reloadData(); renderOwner(); toast("Booking deleted"); }
  } catch (err) { toast(err.message); }
});
$("#setForm").addEventListener("submit", async (e) => {
  e.preventDefault(); const f = e.target, body = {};
  for (const k of SKEYS) body[k] = f[k].value;
  for (const k of ["offerOn", "delivery", "alteration"]) body[k] = f[k].checked;
  body.payModes = { cash: f.pmCash.checked, upi: f.pmUpi.checked, card: f.pmCard.checked }; body.slotLen = Number(f.slotLen.value);
  body.hours = Array.from({ length: 7 }, (_, i) => ({ o: f["ho" + i].value || "10:00", c: f["hc" + i].value || "21:00", x: f["hx" + i].checked }));
  const nb = body.brand.trim().replace(/\s+/g, " "); body.brand = nb;
  if (!nb) { msg($("#setMsg"), "Store name cannot be empty"); return; }
  const renamed = nb.toLowerCase() !== String(S.settings.brand || "").trim().toLowerCase();
  if (renamed && !confirm("Your login name will be: " + nb + "\n\nYour password stays the same. The old name \"" + S.settings.brand + "\" will no longer work for login. OK?")) { msg($("#setMsg"), "Name not changed", false); return; }
  try { const d = await api("/settings", { method: "POST", body }); S.settings = d.settings; SETDIRTY = false; renderAll();
    msg($("#setMsg"), renamed ? "Saved ✓ Your login name will be: " + d.settings.brand : "Settings saved ✓ Now live on the website", true); toast(renamed ? "Your login name will be: " + d.settings.brand : "Settings saved ✓"); }
  catch (err) { msg($("#setMsg"), err.message); }
});
$("#loginSetForm").addEventListener("submit", async (e) => {
  e.preventDefault(); const f = e.target;
  try { const d = await api("/admin-login", { method: "POST", body: { email: f.email.value, password: f.password.value, mobile: f.mobile.value, shopPassword: f.shopPassword.value } }); f.email.value = d.email; f.password.value = ""; const spSet = !!f.shopPassword.value; f.shopPassword.value = ""; f.mobile.value = d.mobile || "";
    msg($("#loginSetMsg"), "Saved ✓" + (spSet ? " Login is now: \"" + S.settings.brand + "\" + new password." : "") + " Gmail login: " + d.email, true); toast("Login settings saved ✓"); }
  catch (err) { msg($("#loginSetMsg"), err.message); }
});
async function loadLoginSet() { try { const d = await api("/admin-login"); $("#loginSetForm").email.value = d.email; $("#loginSetForm").mobile.value = d.mobile || "";
  $("#loginNameNow").textContent = S.settings.brand + (d.shopCustom ? " + your password" : " + password K");
  $("#loginSetHint").textContent = (d.custom ? "Current: " + d.email + " + your own password." : "Current default: " + d.email + " + password K.") + " Do not enter your real Gmail password here; set a separate password."; } catch {} }
$("#bkList") && setInterval(async () => { if (isOwner() && !document.hidden) { const before = S.bookings.filter((b) => !b.seen).length; await loadBookings(); renderOwner(); const now = S.bookings.filter((b) => !b.seen).length; if (now > before) toast("📅 New booking received!"); if (PANE === "bookings" && !$("#v-owner").hidden) markSeen(); } }, 30000);

$("#yr").textContent = new Date().getFullYear();
const setTopH = () => document.documentElement.style.setProperty("--toph", ($(".top").offsetHeight || 96) + "px"); setTopH(); addEventListener("resize", setTopH);
setBookSel(null); drawPF();
renderAll(); load();
})();
