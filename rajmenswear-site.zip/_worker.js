
let _init = null;
function store(env) {
  const db = env.DB;
  if (!_init) _init = db.batch([
    db.prepare("CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL, exp INTEGER)"),
    db.prepare("CREATE TABLE IF NOT EXISTS img (id TEXT PRIMARY KEY, type TEXT, data TEXT NOT NULL)"),
  ]).catch((e) => { _init = null; throw e; });
  const ready = () => _init;
  return {
    async get(k, type) { await ready(); const r = await db.prepare("SELECT v, exp FROM kv WHERE k = ?").bind(k).first();
      if (!r || (r.exp && r.exp < Date.now())) return null; return type === "json" ? JSON.parse(r.v) : r.v; },
    async put(k, v, o = {}) { await ready(); const exp = o.expirationTtl ? Date.now() + o.expirationTtl * 1000 : null;
      await db.prepare("INSERT INTO kv (k, v, exp) VALUES (?, ?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v, exp = excluded.exp").bind(k, String(v), exp).run(); },
    async delete(k) { await ready(); await db.prepare("DELETE FROM kv WHERE k = ?").bind(k).run(); },
    async putImg(id, type, b64) { await ready(); await db.prepare("INSERT INTO img (id, type, data) VALUES (?, ?, ?)").bind(id, type, b64).run(); },
    async list(prefix) { await ready(); const r = await db.prepare("SELECT k, v FROM kv WHERE k LIKE ? LIMIT 2000").bind(prefix + "%").all(); return (r.results || []).map((x) => { try { return { k: x.k, v: JSON.parse(x.v) }; } catch { return { k: x.k, v: null }; } }); },
    async getImg(id) { await ready(); return db.prepare("SELECT type, data FROM img WHERE id = ?").bind(id).first(); },
  };
}

const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
const err = (m, s = 400) => J({ ok: false, error: m }, s);
const QUICK_PASS = "k"; // quick owner login: shop name + "K" (K or k)
const DEFAULT_ADMIN_EMAIL = "kishan@gmail.com", DEFAULT_ADMIN_PASS = "K";
const normEmail = (s) => String(s || "").trim().toLowerCase().replace(/\s+/g, "");
const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9\u0900-\u097f]/g, "");
const CATS = ["Shirt", "Pant", "T-shirt", "Lower", "Extra"];
const rid = (n = 10) => { const a = new Uint8Array(n); crypto.getRandomValues(a); return [...a].map((b) => b.toString(16).padStart(2, "0")).join(""); };
async function sha(s) { const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)); return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join(""); }
async function hashPw(salt, pw) { let h = salt + ":" + pw; for (let i = 0; i < 200; i++) h = await sha(salt + h); return h; }

const DEFAULT_REVIEWS = "Rahul | Great shirt quality and a perfect fit. Fair prices too.\nAmit | The new collection is great. Tried it on at the shop before buying, and the staff were helpful.\nPooja | Bought a festive kurta-shirt for my brother and everyone loved it. Highly recommended!";
const DEFAULT_SETTINGS = { brand: "Raj Men's Wear", tagline: "New styles, fair prices", whatsapp: "", address: "", timing: "10:00 AM – 9:00 PM",
  offerOn: true, offerText: "🪔 Diwali Special: our new festive collection is here!", offerSub: "Book a shop visit and see it first", phone: "", mapsUrl: "", reviews: DEFAULT_REVIEWS,
  logo: "", ownerName: "", email: "", hours: Array.from({ length: 7 }, () => ({ o: "10:00", c: "21:00", x: false })), upi: "", payModes: { cash: true, upi: true, card: false }, gst: "",
  delivery: false, deliveryAreas: "", deliveryCharge: "", alteration: false, returnPolicy: "", instagram: "", facebook: "", slotOpen: "10:00", slotClose: "20:00", slotLen: 30, holidays: "" };
const SEED = [
  ["shirt-1","Shirt","White Oxford Formal Shirt",899,12],["shirt-2","Shirt","Blue Check Casual Shirt",799,8],["shirt-3","Shirt","Black Linen Shirt",1099,5],
  ["pant-1","Pant","Beige Cotton Chinos",1199,10],["pant-2","Pant","Slim Fit Blue Jeans",1299,15],["pant-3","Pant","Grey Formal Trousers",999,6],
  ["tshirt-1","T-shirt","Classic Black Tee",399,25],["tshirt-2","T-shirt","Olive Oversized Tee",499,18],["tshirt-3","T-shirt","White Polo T-shirt",599,9],
  ["lower-1","Lower","Grey Jogger Lower",549,20],["lower-2","Lower","Black Track Lower",499,14],
  ["extra-1","Extra","Denim Jacket",1799,4],["extra-2","Extra","Leather Belt",349,30],["extra-3","Extra","Baseball Cap",299,22],
].map(([id, cat, name, price, stock], i) => ({ id, cat, name, price, stock, img: "/p/" + id + ".jpg", desc: "", updated: Date.now() - i }));

async function getJSON(env, k, d) { const v = await store(env).get(k, "json"); return v == null ? d : v; }
async function settings(env) { const s = { ...DEFAULT_SETTINGS, ...(await getJSON(env, "settings", {})) };
  // the shop name shows in the store's own spelling; the login is matched on the same letters, so only the casing moves
  if (norm(s.brand) === norm(DEFAULT_SETTINGS.brand)) s.brand = DEFAULT_SETTINGS.brand; return s; }
async function products(env) { let p = await store(env).get("products", "json"); if (p == null) { p = []; await store(env).put("products", JSON.stringify(p)); } return p; } // the demo SEED is never re-added: the owner adds his own articles
async function adminMail(env) { const a = await getJSON(env, "adminmail", null); return a && a.email ? a : { email: DEFAULT_ADMIN_EMAIL }; }
async function session(req, env) {
  const t = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!t) return null; const s = await store(env).get("s:" + t, "json"); return s ? { ...s, token: t } : null;
}
async function newSession(env, data) { const t = rid(24); await store(env).put("s:" + t, JSON.stringify(data), { expirationTtl: 60 * 60 * 24 * 30 }); return t; }
const STATUSES = ["active", "hidden", "out_of_stock"];
const BK_STATUS = ["pending", "confirmed", "picked_up", "cancelled", "no_show"];
const arr = (v, L = 12, M = 24) => (Array.isArray(v) ? v : String(v || "").split(/[,/]+/)).map((x) => String(x).trim().slice(0, M)).filter(Boolean).filter((x, i, a) => a.findIndex((y) => y.toLowerCase() === x.toLowerCase()) === i).slice(0, L);
const slug = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9\u0900-\u097f]+/g, "-").replace(/^-|-$/g, "") || "x";
const vid = (size, colour) => (!size && !colour ? "std" : slug(size || "any") + "__" + slug(colour || "any"));
function variantsOf(p) { const sz = p.sizes || [], cl = p.colours || [], out = [];
  if (!sz.length && !cl.length) return [{ variantId: "std", size: "", colour: "" }];
  for (const s of sz.length ? sz : [""]) for (const c of cl.length ? cl : [""]) out.push({ variantId: vid(s, c), size: s, colour: c });
  return out; }
function cleanProduct(b, old = {}) {
  const p = { ...old };
  if (b.name !== undefined) p.name = String(b.name).trim().slice(0, 80);
  if (b.cat !== undefined || b.category !== undefined) { const c = b.category ?? b.cat; p.cat = CATS.includes(c) ? c : "Extra"; }
  if (b.price !== undefined) p.price = Math.max(0, Math.round(Number(b.price) || 0));
  if (b.images !== undefined) p.images = (Array.isArray(b.images) ? b.images : []).map((x) => String(x).slice(0, 300)).filter((x) => /^\/(img|p)\/[\w.-]+$/.test(x)).slice(0, 8);
  else if (b.img !== undefined) p.images = b.img ? [String(b.img).slice(0, 300)] : [];
  if (b.desc !== undefined) p.desc = String(b.desc).trim().slice(0, 300);
  if (b.mrp !== undefined) p.mrp = Math.max(0, Math.round(Number(b.mrp) || 0));
  if (b.sizes !== undefined) p.sizes = arr(b.sizes);
  if (b.colours !== undefined) p.colours = arr(b.colours);
  if (b.status !== undefined) p.status = STATUSES.includes(b.status) ? b.status : "active";
  if (b.tag !== undefined) p.tag = ["new", "best"].includes(b.tag) ? b.tag : "";
  p.productId = p.id; p.category = p.cat; p.images = p.images || []; p.img = p.images[0] || ""; p.sizes = p.sizes || []; p.colours = p.colours || []; p.status = p.status || "active";
  delete p.stock; p.updated = Date.now(); return p;
}
// ---- data model v5 (CLOTHING_STORE): products, inventory, bookings, customers, payments, admins, settings ----
let _mig = null;
async function migrate(env) {
  const st = store(env);
  if ((await st.get("schema")) === "5") return;
  const oldP = await st.get("products", "json"), oldB = await getJSON(env, "bookings", []), oldS = await getJSON(env, "settings", {});
  // back up the old (v4) data first, untouched
  if (!(await st.get("backup:v4:products"))) {
    await st.put("backup:v4:products", JSON.stringify(oldP == null ? SEED : oldP)); await st.put("backup:v4:bookings", JSON.stringify(oldB));
    await st.put("backup:v4:settings", JSON.stringify(oldS)); await st.put("backup:v4:at", String(Date.now()));
  }
  const src = oldP == null ? SEED : oldP, inv = [];
  const prods = src.map((o) => {
    const p = cleanProduct({ images: o.images || (o.img ? [o.img] : []), sizes: o.sizes || [], colours: o.colours || [], status: o.status || "active" }, { ...o });
    p.updated = o.updated; const vs = variantsOf(p), stock = Math.max(0, Math.round(Number(o.stock) || 0));
    vs.forEach((v, i) => inv.push({ productId: p.id, variantId: v.variantId, size: v.size, colour: v.colour, physicalStock: vs.length === 1 ? stock : i === 0 ? stock : 0, reservedStock: 0 }));
    return p; });
  const custs = [], bks = oldB.map((b) => {
    let c = null; const mob = normMob(b.phone);
    if (mob) c = custs.find((x) => x.mobile === mob);
    if (!c) { c = { customerId: "c" + rid(5), name: b.name, mobile: mob, account: b.account || "", createdAt: b.created || Date.now() }; custs.push(c); }
    return { ...b, bookingId: b.id, customerId: c.customerId, productSnapshot: null, quantity: 0, totalAmount: 0, pickupDate: b.time, status: "confirmed", createdAt: b.created || Date.now(), stockState: "none" };
  });
  const pays = bks.map((b) => ({ bookingId: b.id, amount: 0, method: "", status: "unpaid" }));
  await st.put("products", JSON.stringify(prods)); await st.put("inventory", JSON.stringify(inv)); await st.put("bookings", JSON.stringify(bks));
  await st.put("customers", JSON.stringify(custs)); await st.put("payments", JSON.stringify(pays));
  const am = await adminMail(env);
  await st.put("admins", JSON.stringify([{ adminId: "owner", role: "owner", loginName: "shop name (settings.brand)", email: am.email }]));
  await st.put("schema", "5");
}
const normMob = (m) => { let d = String(m || "").replace(/\D/g, ""); if (d.length === 12 && d.startsWith("91")) d = d.slice(2); if (d.length === 11 && d.startsWith("0")) d = d.slice(1); return d.slice(0, 15); };
async function inventory(env) { return getJSON(env, "inventory", []); }
function syncInv(inv, p, initial) { // make sure every current variant of p has a row; keep old rows' numbers
  const vs = variantsOf(p), mine = inv.filter((r) => r.productId === p.id), out = inv.filter((r) => r.productId !== p.id);
  const std = mine.find((r) => r.variantId === "std");
  vs.forEach((v, i) => { const r = mine.find((x) => x.variantId === v.variantId);
    if (r) out.push({ ...r, size: v.size, colour: v.colour });
    else out.push({ productId: p.id, variantId: v.variantId, size: v.size, colour: v.colour, physicalStock: initial != null ? initial : (i === 0 && std && v.variantId !== "std" ? std.physicalStock : 0), reservedStock: 0 }); });
  // keep rows that still hold a reservation, so nothing reserved is lost
  mine.filter((r) => !vs.some((v) => v.variantId === r.variantId) && r.reservedStock > 0).forEach((r) => out.push({ ...r, retired: true }));
  return out; }
const avail = (r) => Math.max(0, (r.physicalStock || 0) - (r.reservedStock || 0));
function publicProducts(list, inv, owner) {
  return list.filter((p) => owner || p.status !== "hidden").map((p) => { const rows = inv.filter((r) => r.productId === p.id && !r.retired), a = {};
    rows.forEach((r) => (a[r.variantId] = avail(r)));
    const total = rows.reduce((s, r) => s + avail(r), 0);
    return { ...p, avail: a, stock: p.status === "out_of_stock" ? 0 : total, ...(owner ? { physical: rows.reduce((s, r) => s + (r.physicalStock || 0), 0), reserved: rows.reduce((s, r) => s + (r.reservedStock || 0), 0) } : {}) }; });
}

async function api(req, env, url) {
  const path = url.pathname.replace(/^\/api/, ""), m = req.method;
  let body = {}; if (m === "POST" || m === "PUT") { try { body = await req.json(); } catch { body = {}; } }
  if (!_mig) _mig = migrate(env).catch((e) => { _mig = null; throw e; });
  await _mig;
  const ses = await session(req, env), isOwner = ses && ses.role === "owner";

  if (path === "/data" && m === "GET") {
    const inv = await inventory(env), out = { ok: true, settings: await settings(env), products: publicProducts(await products(env), inv, isOwner), me: ses ? { name: ses.name, role: ses.role } : null };
    if (isOwner) out.inventory = inv.filter((r) => !r.retired);
    return J(out);
  }
  // one shared Sign up / Login form: the owner is recognised by ID (shop name or owner Gmail) + owner password
  const ownerId = async (id) => {
    const s = await settings(env), n = norm(id), e = normEmail(id), a = await adminMail(env);
    if (e.includes("@")) return e === a.email ? "mail" : null;
    return n && n === norm(s.brand) ? "shop" : null;
  };
  const reservedName = async (id) => { const s = await settings(env), n = norm(id); return !!n && (n === norm(s.brand) || n === norm(DEFAULT_SETTINGS.brand)); };
  const ownerAuth = async (kind, pw) => {
    const ip = req.headers.get("cf-connecting-ip") || "x", rk = "rl:" + ip, tries = await getJSON(env, rk, 0);
    if (tries >= 8) return { limited: true };
    pw = String(pw || "").trim(); let ok = false;
    if (kind === "mail") { const a = await adminMail(env); ok = a.hash ? (await hashPw(a.salt, pw)) === a.hash : pw.toLowerCase() === DEFAULT_ADMIN_PASS.toLowerCase(); }
    else { const op = await getJSON(env, "ownerpass", null); ok = op && op.hash ? (await hashPw(op.salt, pw)) === op.hash : pw.toLowerCase() === QUICK_PASS; }
    if (!ok) { await store(env).put(rk, JSON.stringify(tries + 1), { expirationTtl: 900 }); return { ok: false }; }
    await store(env).delete(rk);
    const s = await settings(env), me = { name: s.brand, role: "owner" };
    return { ok: true, res: J({ ok: true, token: await newSession(env, me), me }) };
  };
  if ((path === "/signup" || path === "/login") && m === "POST") {
    const kind = await ownerId(body.name);
    if (kind) {
      // Sign up never opens the owner panel: the shop name / owner Gmail is simply "taken"
      if (path === "/signup") return err("This name is already registered. Please log in or choose another name", 409);
      const r = await ownerAuth(kind, body.password);
      if (r.limited) return err("Too many wrong attempts. Please try again in 15 minutes.", 429);
      if (r.ok) return r.res;
      return err("Wrong name or password", 401);
    }
  }
  if (path === "/signup" && m === "POST") {
    if (await reservedName(body.name)) return err("This name is already registered. Please log in or choose another name", 409);
    const name = String(body.name || "").trim().slice(0, 60), pw = String(body.password || "");
    if (name.length < 2) return err("Name must be at least 2 letters");
    if (pw.length < 4) return err("Password must be at least 4 characters");
    const key = "u:" + norm(name); if (!norm(name)) return err("Please enter a valid name");
    if (await store(env).get(key)) return err("This name is already registered. Please log in or choose another name", 409);
    const salt = rid(8); await store(env).put(key, JSON.stringify({ name, salt, hash: await hashPw(salt, pw), created: Date.now() }));
    const cnt = (await getJSON(env, "usercount", 0)) + 1; await store(env).put("usercount", JSON.stringify(cnt));
    return J({ ok: true, token: await newSession(env, { name, role: "user" }), me: { name, role: "user" } });
  }
  if (path === "/login" && m === "POST") {
    const u = await store(env).get("u:" + norm(body.name), "json");
    if (!u || (await hashPw(u.salt, String(body.password || ""))) !== u.hash) return err("Wrong name or password", 401);
    return J({ ok: true, token: await newSession(env, { name: u.name, role: "user" }), me: { name: u.name, role: "user" } });
  }
  if (path === "/owner-login" && m === "POST") { // legacy; same check as the shared form
    const kind = body.email !== undefined ? ((await ownerId(String(body.email || "x@"))) === "mail" ? "mail" : null) : ((await ownerId(body.shop)) === "shop" ? "shop" : null);
    const r = kind ? await ownerAuth(kind, body.password) : { ok: false };
    if (r.limited) return err("Too many wrong attempts. Please try again in 15 minutes.", 429);
    return r.ok ? r.res : err("Wrong name or password", 401);
  }
  if (path === "/logout" && m === "POST") { if (ses) await store(env).delete("s:" + ses.token); return J({ ok: true }); }

  if (path === "/bookings" && m === "POST") {
    if (!ses) return err("Please log in to book", 401);
    const name = String(body.name || "").trim().slice(0, 60), time = String(body.time || body.pickupDate || "").slice(0, 40), mob = normMob(body.phone || body.mobile);
    if (!name || !time) return err("Please enter both name and time");
    if (mob.length !== 10) return err("Please enter a valid 10-digit mobile number");
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(time)) return err("Please choose a valid date and time");
    { const st = await settings(env), dk = time.slice(0, 10), wd = new Date(dk + "T12:00:00Z").getUTCDay();
      if (String(st.holidays || "").includes(dk) || (Array.isArray(st.hours) && st.hours[wd] && st.hours[wd].x)) return err("The store is closed on this day. Please choose another day"); }
    let snap = null, qty = 0, total = 0, inv = null, row = null;
    if (body.productId) {
      const p = (await products(env)).find((x) => x.id === body.productId);
      if (!p || p.status === "hidden") return err("This product is no longer available", 404);
      if (p.status === "out_of_stock") return err("This product is currently out of stock");
      const size = String(body.size || ""), colour = String(body.colour || "");
      if (p.sizes.length && !p.sizes.includes(size)) return err("Please choose a size");
      if (p.colours.length && !p.colours.includes(colour)) return err("Please choose a colour");
      qty = Math.round(Number(body.quantity || body.qty) || 1); if (qty < 1 || qty > 20) return err("Quantity must be between 1 and 20");
      inv = await inventory(env); const v = vid(p.sizes.length ? size : "", p.colours.length ? colour : ""); row = inv.find((r) => r.productId === p.id && r.variantId === v);
      const av = row ? avail(row) : 0;
      if (av < qty) return err(av ? "Only " + av + " left. Please reduce the quantity" : "This size/colour is sold out", 409);
      row.reservedStock = (row.reservedStock || 0) + qty; total = qty * p.price;
      snap = { productId: p.id, variantId: v, name: p.name, category: p.cat, price: p.price, size: p.sizes.length ? size : "", colour: p.colours.length ? colour : "", image: p.images[0] || "" };
    }
    // customers: link by mobile, else create
    const custs = await getJSON(env, "customers", []); let c = custs.find((x) => x.mobile === mob);
    if (!c) { c = { customerId: "c" + rid(5), name, mobile: mob, account: ses.role === "user" ? ses.name : "", createdAt: Date.now() }; custs.unshift(c); }
    else { c.name = name || c.name; if (ses.role === "user" && !c.account) c.account = ses.name; }
    const now = Date.now(), id = rid(6);
    const bk = { id, bookingId: id, customerId: c.customerId, name, phone: mob, productSnapshot: snap, quantity: qty, totalAmount: total, pickupDate: time, time,
      status: "pending", createdAt: now, created: now, note: String(body.note || "").trim().slice(0, 300), account: ses.name, seen: false, stockState: snap ? "reserved" : "none" };
    const list = await getJSON(env, "bookings", []); list.unshift(bk);
    const pays = await getJSON(env, "payments", []); pays.unshift({ bookingId: id, amount: total, method: "", status: "unpaid" });
    if (inv) await store(env).put("inventory", JSON.stringify(inv));
    await store(env).put("bookings", JSON.stringify(list.slice(0, 1000))); await store(env).put("customers", JSON.stringify(custs)); await store(env).put("payments", JSON.stringify(pays.slice(0, 1000)));
    return J({ ok: true, booking: { id, time, totalAmount: total, quantity: qty, status: "pending" } });
  }

  // ---- owner only below ----
  if (!isOwner) return err("Your account cannot do this", 403);
  const SEEN_CUTOFF = 1793440160041; // bookings made before the "New" badge existed count as seen
  const withSeen = (list) => list.map((b) => ({ ...b, seen: b.seen !== undefined ? !!b.seen : (b.created || 0) < SEEN_CUTOFF }));
  const ownerBundle = async (extra = {}) => ({ ok: true, bookings: withSeen(await getJSON(env, "bookings", [])), payments: await getJSON(env, "payments", []), customers: await getJSON(env, "customers", []),
    inventory: (await inventory(env)).filter((r) => !r.retired), users: await getJSON(env, "usercount", 0), ...extra });
  if (path === "/bookings" && m === "GET") return J(await ownerBundle());
  if (path === "/bookings/seen" && m === "POST") {
    const list = (await getJSON(env, "bookings", [])).map((b) => ({ ...b, seen: true }));
    await store(env).put("bookings", JSON.stringify(list)); return J(await ownerBundle());
  }
  let mm;
  if ((mm = path.match(/^\/bookings\/([\w-]+)\/pay$/)) && m === "POST") {
    const list = await getJSON(env, "bookings", []), b = list.find((x) => x.id === mm[1]); if (!b) return err("Booking not found", 404);
    const pays = await getJSON(env, "payments", []); let pr = pays.find((x) => x.bookingId === b.id);
    if (!pr) { pr = { bookingId: b.id, amount: b.totalAmount || 0, method: "", status: "unpaid" }; pays.unshift(pr); }
    const stt = ["unpaid", "paid", "refunded"].includes(body.status) ? body.status : "paid";
    if (stt === "paid") { const meth = ["cash", "upi", "card"].includes(body.method) ? body.method : ""; if (!meth) return err("Please choose a payment method: Cash / UPI / Card"); pr.method = meth; pr.paidAt = Date.now(); }
    if (body.amount !== undefined) pr.amount = Math.max(0, Math.round(Number(body.amount) || 0)); else if (stt === "paid" && !pr.amount) pr.amount = b.totalAmount || 0;
    if (stt === "unpaid") { pr.method = ""; delete pr.paidAt; }
    if (stt === "refunded") pr.refundedAt = Date.now();
    pr.status = stt; await store(env).put("payments", JSON.stringify(pays)); return J(await ownerBundle());
  }
  if ((mm = path.match(/^\/bookings\/([\w-]+)$/))) {
    let list = await getJSON(env, "bookings", []); const b = list.find((x) => x.id === mm[1]); if (!b) return err("Booking not found", 404);
    const inv = await inventory(env), row = b.productSnapshot ? inv.find((r) => r.productId === b.productSnapshot.productId && r.variantId === b.productSnapshot.variantId) : null, q = b.quantity || 0;
    const release = () => { if (row && b.stockState === "reserved") row.reservedStock = Math.max(0, (row.reservedStock || 0) - q); b.stockState = "released"; };
    if (m === "DELETE") {
      if (b.stockState === "reserved") release();
      list = list.filter((x) => x.id !== b.id);
      await store(env).put("payments", JSON.stringify((await getJSON(env, "payments", [])).filter((x) => x.bookingId !== b.id)));
    } else if (m === "PUT") {
      const to = body.status === "done" ? "picked_up" : body.status === "new" ? "pending" : body.status;
      if (!BK_STATUS.includes(to)) return err("Invalid status");
      if (b.productSnapshot && to !== b.status) {
        if (to === "picked_up") {
          if (!row) return err("No stock record found for this product");
          if (b.stockState === "released") { if (avail(row) < q) return err("Not enough stock. Please increase it in Stock first"); row.reservedStock += q; b.stockState = "reserved"; }
          if (b.stockState === "reserved") { row.physicalStock = Math.max(0, row.physicalStock - q); row.reservedStock = Math.max(0, row.reservedStock - q); b.stockState = "consumed"; }
        } else if (to === "cancelled" || to === "no_show") {
          if (b.stockState === "reserved") release();
          else if (b.stockState === "consumed" && row) { row.physicalStock += q; b.stockState = "released"; }
        } else { // pending / confirmed: hold the stock again
          if (b.stockState === "consumed" && row) { row.physicalStock += q; row.reservedStock += q; b.stockState = "reserved"; }
          else if (b.stockState === "released" && row) { if (avail(row) < q) return err("Not enough stock to reserve again"); row.reservedStock += q; b.stockState = "reserved"; }
        }
      }
      b.status = to; b.updatedAt = Date.now();
    }
    if (row) await store(env).put("inventory", JSON.stringify(inv));
    await store(env).put("bookings", JSON.stringify(list)); return J(await ownerBundle());
  }
  if (path === "/customers" && m === "GET") {
    const acc = (await store(env).list("u:")).filter((x) => x.v).map((x) => ({ name: x.v.name, created: x.v.created || 0 }));
    return J(await ownerBundle({ accounts: acc }));
  }
  if ((mm = path.match(/^\/customers\/([\w-]+)$/)) && m === "DELETE") {
    const custs = (await getJSON(env, "customers", [])).filter((x) => x.customerId !== mm[1]);
    await store(env).put("customers", JSON.stringify(custs)); return J(await ownerBundle());
  }
  if ((mm = path.match(/^\/inventory\/([\w-]+)$/)) && m === "PUT") {
    const p = (await products(env)).find((x) => x.id === mm[1]); if (!p) return err("Product not found", 404);
    let inv = syncInv(await inventory(env), p); const ch = body.stock || {};
    for (const r of inv) if (r.productId === p.id && ch[r.variantId] !== undefined) {
      const n = Math.max(0, Math.round(Number(ch[r.variantId]) || 0));
      if (n < (r.reservedStock || 0)) return err(`${r.size || ""} ${r.colour || ""}: ${r.reservedStock} are reserved, so stock cannot go below that`.trim());
      r.physicalStock = n; }
    await store(env).put("inventory", JSON.stringify(inv)); return J({ ok: true, inventory: inv.filter((r) => !r.retired), products: publicProducts(await products(env), inv, true) });
  }
  if (path === "/settings" && m === "POST") {
    const s = await settings(env), n = { ...s }, str = (v, L) => String(v ?? "").trim().slice(0, L);
    const LIM = { brand: 60, tagline: 100, address: 200, timing: 100, offerText: 100, offerSub: 100, ownerName: 60, email: 80, gst: 20, deliveryAreas: 200, deliveryCharge: 80, returnPolicy: 400, upi: 60 };
    for (const k in LIM) if (body[k] !== undefined) n[k] = str(body[k], LIM[k]);
    for (const k of ["offerOn", "delivery", "alteration"]) if (body[k] !== undefined) n[k] = !!body[k];
    if (body.payModes !== undefined) { const pm = body.payModes || {}; n.payModes = { cash: !!pm.cash, upi: !!pm.upi, card: !!pm.card }; }
    if (body.phone !== undefined) n.phone = String(body.phone).replace(/[^\d+]/g, "").slice(0, 15);
    const url = (v) => { const u = str(v, 400); return /^https:\/\//i.test(u) ? u : ""; };
    for (const k of ["mapsUrl", "instagram", "facebook"]) if (body[k] !== undefined) n[k] = url(body[k]);
    if (body.logo !== undefined) { const l = str(body.logo, 200); n.logo = /^\/img\/[a-f0-9]+$/.test(l) ? l : ""; }
    if (body.reviews !== undefined) n.reviews = String(body.reviews).slice(0, 1500);
    if (body.hours !== undefined && Array.isArray(body.hours)) { const T = (t, d) => (/^\d{2}:\d{2}$/.test(t) ? t : d); n.hours = Array.from({ length: 7 }, (_, i) => { const h = body.hours[i] || {}; return { o: T(h.o, "10:00"), c: T(h.c, "21:00"), x: !!h.x }; }); }
    if (body.slotOpen !== undefined) n.slotOpen = /^\d{2}:\d{2}$/.test(body.slotOpen) ? body.slotOpen : "10:00";
    if (body.slotClose !== undefined) n.slotClose = /^\d{2}:\d{2}$/.test(body.slotClose) ? body.slotClose : "20:00";
    if (body.slotLen !== undefined) n.slotLen = [15, 30, 45, 60].includes(Number(body.slotLen)) ? Number(body.slotLen) : 30;
    if (n.slotOpen && n.slotClose && n.slotOpen >= n.slotClose) return err("Booking closing time must be after the opening time");
    if (body.holidays !== undefined) n.holidays = [...new Set(String(body.holidays).match(/\d{4}-\d{2}-\d{2}/g) || [])].sort().slice(0, 60).join(", ");
    if (!norm(n.brand)) n.brand = s.brand;
    if (norm(n.brand) !== norm(s.brand)) {
      // the shop name is the owner's login name: it must not collide with a visitor account
      if (await store(env).get("u:" + norm(n.brand))) return err("A customer account with this name already exists. Please choose a different name", 409);
      if (n.brand.includes("@")) return err("Shop name cannot contain @");
    }
    if (body.whatsapp !== undefined) { let w = String(body.whatsapp).replace(/\D/g, ""); if (w.length === 10) w = "91" + w; n.whatsapp = w; }
    await store(env).put("settings", JSON.stringify(n)); return J({ ok: true, settings: n });
  }
  if (path === "/users/delete" && m === "POST") {
    const key = "u:" + norm(body.name); if (!norm(body.name) || !(await store(env).get(key))) return err("Account not found", 404);
    await store(env).delete(key); const cnt = Math.max(0, (await getJSON(env, "usercount", 0)) - 1); await store(env).put("usercount", JSON.stringify(cnt));
    return J({ ok: true, users: cnt });
  }
  if (path === "/admin-login" && m === "GET") { const a = await adminMail(env); const op = await getJSON(env, "ownerpass", null); return J({ ok: true, email: a.email, custom: !!a.hash, mobile: a.mobile || "", shopCustom: !!(op && op.hash) }); }
  if (path === "/admin-login" && m === "POST") {
    const a = await adminMail(env), email = normEmail(body.email || a.email), pw = String(body.password || "").trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return err("Please enter a valid Gmail / email ID");
    if (pw.length > 60) return err("Password must be under 60 characters");
    const n = { email, mobile: a.mobile || "" };
    if (body.mobile !== undefined) { const mb = String(body.mobile).replace(/[^\d+]/g, "").slice(0, 15); if (mb && mb.replace(/\D/g, "").length < 10) return err("Please enter a 10-digit mobile number"); n.mobile = mb; }
    if (pw) { n.salt = rid(8); n.hash = await hashPw(n.salt, pw); } else if (a.hash) { n.salt = a.salt; n.hash = a.hash; }
    const sp = String(body.shopPassword || "").trim();
    if (sp) { if (sp.length > 60) return err("Password must be under 60 characters"); if (sp.toLowerCase() === QUICK_PASS) await store(env).delete("ownerpass"); else { const salt = rid(8); await store(env).put("ownerpass", JSON.stringify({ salt, hash: await hashPw(salt, sp) })); } }
    const op = await getJSON(env, "ownerpass", null);
    await store(env).put("adminmail", JSON.stringify(n)); return J({ ok: true, email, custom: !!n.hash, mobile: n.mobile, shopCustom: !!(op && op.hash) });
  }
  if (path === "/products" && m === "POST") {
    const p = cleanProduct({ cat: "Extra", price: 0, images: [], desc: "", sizes: [], colours: [], status: "active", ...body }, { id: rid(6) });
    if (!p.name) return err("Please enter a product name");
    const list = await products(env); list.unshift(p);
    const inv = syncInv(await inventory(env), p, Math.max(0, Math.round(Number(body.stock) || 0)));
    await store(env).put("products", JSON.stringify(list)); await store(env).put("inventory", JSON.stringify(inv));
    return J({ ok: true, product: p, products: publicProducts(list, inv, true), inventory: inv.filter((r) => !r.retired) });
  }
  if (path === "/prices" && m === "POST") {
    const ch = body.prices || {}; const list = (await products(env)).map((p) => (ch[p.id] !== undefined ? cleanProduct({ price: ch[p.id] }, p) : p));
    await store(env).put("products", JSON.stringify(list)); return J({ ok: true, products: publicProducts(list, await inventory(env), true) });
  }
  if ((mm = path.match(/^\/products\/([\w-]+)$/))) {
    let list = await products(env); const i = list.findIndex((p) => p.id === mm[1]); if (i < 0) return err("Product not found", 404);
    let inv = await inventory(env);
    if (m === "DELETE") { const id = list[i].id; list.splice(i, 1); inv = inv.filter((r) => r.productId !== id); }
    else if (m === "PUT") { list[i] = cleanProduct(body, list[i]); inv = syncInv(inv, list[i]); }
    else return err("method", 405);
    await store(env).put("products", JSON.stringify(list)); await store(env).put("inventory", JSON.stringify(inv));
    return J({ ok: true, products: publicProducts(list, inv, true), inventory: inv.filter((r) => !r.retired) });
  }
  if (path === "/upload" && m === "POST") {
    const mt = String(body.data || "").match(/^data:(image\/(?:jpeg|png|webp));base64,(.+)$/);
    if (!mt) return err("Please upload photos only (jpg/png)");
    if (mt[2].length > 1.4e6) return err("Photo is too large. Please try a smaller one");
    const id = rid(8); await store(env).putImg(id, mt[1], mt[2]); return J({ ok: true, url: "/img/" + id });
  }
  return err("Not found", 404);
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    try {
      if (url.pathname.startsWith("/api/")) return await api(req, env, url);
      const im = url.pathname.match(/^\/img\/([a-f0-9]+)$/);
      if (im) { const r = await store(env).getImg(im[1]); if (!r) return new Response("not found", { status: 404 });
        const bin = Uint8Array.from(atob(r.data), (c) => c.charCodeAt(0));
        return new Response(bin, { headers: { "content-type": r.type || "image/jpeg", "cache-control": "public, max-age=31536000, immutable" } }); }
      if (/^\/admin\/?$/.test(url.pathname)) {
        // hidden admin login page: same app shell, never linked from the visitor page
        const r = await env.ASSETS.fetch(new Request(new URL("/", url), req));
        const h = new Headers(r.headers); h.set("cache-control", "no-store"); h.set("x-robots-tag", "noindex, nofollow");
        return new Response(r.body, { status: r.status, headers: h });
      }
      return env.ASSETS.fetch(req);
    } catch (e) { return err("Server error: " + (e && e.message), 500); }
  },
};
